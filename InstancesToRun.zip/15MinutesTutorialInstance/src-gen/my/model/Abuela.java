package my.model;

public class Abuela {
}
