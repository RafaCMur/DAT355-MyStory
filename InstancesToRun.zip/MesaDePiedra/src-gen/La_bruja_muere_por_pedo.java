public class La_bruja_muere_por_pedo extends PartOfStory{
	
	public La_bruja_muere_por_pedo() {
		this.addGameText("Aslan, el le�n, se tir� un pedo enorme que hizo perecer a la bruja."
		+ "	Fin.");
		
		this.addOption("A", "Me pego un tiro", new Has_perdido());
	}
}
