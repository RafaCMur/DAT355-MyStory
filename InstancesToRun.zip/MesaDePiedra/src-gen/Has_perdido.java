public class Has_perdido extends PartOfStory{
	
	public Has_perdido() {
		this.addGameText("Has perdido, jijijijiji");
	}
}
