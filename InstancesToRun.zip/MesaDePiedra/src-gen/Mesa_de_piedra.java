public class Mesa_de_piedra extends PartOfStory{
	
	public Mesa_de_piedra() {
		this.addGameText("Jadis, La reina de Narnia! anunci� el enano."
		+ "La bruja blanca lleg� ante la mesa de piedra y dijo:"
		+ "- Aslan, �sabes lo que es la magia insondable? Me debes al chico"
		+ "  y lo sabes");
		
		this.setQuestion("�Qu� haces?");
		
		this.addOption("A", "Entrego al chico", new Leon_entrega_a_Edmund());
		this.addOption("B", "Me entrego a la reina en vez de entregar al chico", new Aslan_Se_Entrega());
		this.addOption("C", "Me tiro un pedo", new La_bruja_muere_por_pedo());
	}
}
