public class Leon_entrega_a_Edmund extends PartOfStory{
	
	public Leon_entrega_a_Edmund() {
		this.addGameText("Al entregar el le�n al chico, la profec�a de los cuatro tronos de Cair Paravel jam�s lleg�"
		+ "a cumplirse. La bruja sacrific� al chaval en la mesa de piedra a sangre fr�a. Despu�s, una gran guerra"
		+ "comenz� entre los aliados del le�n y la bruja, sin contar a los tres otros hijos de Ad�n y Eva, que"
		+ "intentaron escapar de Narnia y volver al mundo humano. Pero la bruja fue m�s audaz y envi� a sus secuaces"
		+ "para arrebatarles la vida. Los lobos enviados por la bruja encontraron a los 3 hermanos restantes"
		+ "y los devoraron al instante. "
		+ ""
		+ "Despu�s, una gran batalla comenz� entre los aliados del Le�n y la bruja, pero como la profec�a no pudo"
		+ "cumplirse, Jadis sali� victoriosa y manch� su espada con la sangre del Le�n.");

		this.setDirectRef(new Has_perdido());
	}
}
