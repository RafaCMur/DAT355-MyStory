public class Hooray extends PartOfStory{
	
	public Hooray() {
		this.addGameText("Hooray! You have solved all the questions!");

		this.setDirectRef(new Congrats());
	}
}
