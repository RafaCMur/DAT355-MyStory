public class Wheel_29 extends PartOfStory{
	
	public Wheel_29() {
		this.addGameText("The 26 wheel was the dominant one in the market. Then the 29 appeared, a larger wheel,"
		+ "which forced bike manufacturers to make huge frames to fit the wheel. Little by little the manufacturers were"
		+ "reducing the tamanium of the frame, until reaching today, which we have rolled 29 in size S");
		this.addGameText("Then the 27.5 appeared, but that's another story");
		
		this.setQuestion("Question: Why did the 29 enter the market? What are its main advantages compared to the 26?");
		
		this.addOption("A", "The 29 maintains the speed more, it makes the biker able to overcomes obstacles easier and it has more traccion", new Hooray());
		this.addOption("B", "The 29 accelerates more, it makes the biker able to overcomes obstacles easier and it has more traccion", new Fail());
		this.addOption("C", "The 29 accelerates more, it is more manageable and it has more traccion", new Fail());
	}
}
