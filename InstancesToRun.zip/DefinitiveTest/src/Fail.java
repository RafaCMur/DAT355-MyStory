public class Fail extends PartOfStory{
	
	public Fail() {
		this.addGameText("You have failed");
	}
}
