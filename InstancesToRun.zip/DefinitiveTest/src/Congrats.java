public class Congrats extends PartOfStory{
	
	public Congrats() {
		this.addGameText("CONGRATULATIONS!!! YOU HAVE WON!");
	}
}
