public class Drivetrain_1x extends PartOfStory{
	
	public Drivetrain_1x() {
		this.addGameText("In the history of bikes drivetrains were 3x, having 3 plates in the front part. Then the number decreased to 2 and finally to 1");
		
		this.setQuestion("Why?");
		
		this.addOption("A", "Because it weights less, it's simpler mechanically and it has more speed options", new Fail());
		this.addOption("B", "Because it weights less, it's simpler mechanically and the changes between speeds are softer", new Wheel_29());
		this.addOption("C", "Even though it weights more, the mechanic simplicity allows the drivetrain to be more resilient", new Fail());
	}
}
