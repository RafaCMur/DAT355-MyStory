public class Option {
	private String id;
	private String content;
	private PartOfStory ref;
	
	public Option (String id, String content, PartOfStory ref) {
		this.id = id;
		this.content = content;
		this.ref = ref;
	}
	
	public String getId() {
		return id;
	}
	
	public String getContent() {
		return content;
	}
	
	public PartOfStory getRef() {
		return ref;
	}
	
	@Override
	public String toString () {
		return id + ": " + content;
	}
}
