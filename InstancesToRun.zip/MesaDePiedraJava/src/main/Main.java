package main;

public class Main {
	
	private static PartOfStory currentPart = null;
	private static PartOfStory previousPart = null;
	private static Window w1;
	static String sharedOpt = null;  //Shared field between this class and Window
	static String _continue = null;  //Shared field between this class and Window
	
	
	/**
	 * In case a part of a story doesn't have any option to choose, this method should be called.
	 * A direct reference means that the part of story part has another part following it.
	 * It will go to the next part of the story if it exists. Otherwise, the game will end.
	 * @param part part of story to be evaluated.
	 */
	private static void directRef(PartOfStory part) {
		previousPart = currentPart;
		if (part.getDirectRef() != null) {
			currentPart = part.getDirectRef();
		};
		w1.addContinue();
		w1.refreshButtons();
		waitForContinue();
	}
	
	
	/**
	 * In case that a part of a story has options to choose, this method should be called.
	 * It will simply follow one behaviour or another depending on the option chosen. That
	 * means going to one or another part of the story.
	 */
	private static void thereAreOptions(PartOfStory part) {
		
		part.getOptions().forEach(opt -> w1.addNewButton(opt.getId(), opt.getContent()));
		w1.refreshButtons();
		
		String userOption = waitForButton();
		
		int i = 0;
		boolean found = false;
		Option chosenOpt = null;
		
		while (i < part.getOptions().size() && !found) {
			if(userOption.equals(part.getOptions().get(i).getId())) {
				found = true;
				chosenOpt = part.getOptions().get(i);
			}
			i++;
		}
		
		//We update the current part of the story
		previousPart = currentPart;
		currentPart = chosenOpt.getRef();
	}
	

	/**
	 * Reads one given part of the story, which means initializing all the texts, question
	 * and options in the game window.
	 * @param part part of the story to be red.
	 */
	private static void readPart(PartOfStory part) {

		w1.clearAll();

		if (!part.getGameTexts().isEmpty()) {
			part.getGameTexts().forEach(gt -> w1.addTextToArea(gt));
		}

		if (part.getQuestion() != null) {
			w1.setQuestion(part.getQuestion());
		}

		if (part.getOptions().isEmpty()) {
			directRef(part);
		} else {
			thereAreOptions(part);
		}
	}
	
	
	/**
	 * This method will wait for user interaction with the "Continue" button in the screen.
	 */
	private static void waitForContinue() {
		while (_continue == null) {
	        try {
	            Thread.sleep(500);
	        }
	        catch (InterruptedException e) {}
	    }
		_continue = null;
	}
	
	
	/**
	 * This method will wait for user interaction with the option buttons in the screen.
	 * @return the option clicked
	 */
	private static String waitForButton() {
		String aux = null;
		while (sharedOpt == null) {
	        try {
	            Thread.sleep(500);
	        }
	        catch (InterruptedException e) {}
	    }
		aux = sharedOpt;
		sharedOpt = null;
		return aux;
	}


	/**
	 * Main method
	 * @param Args
	 */
	public static void main(String Args[]) {
		//Initial part
		PartOfStory start = new Mesa_de_piedra();
		currentPart = start;
		//Initializing window
		w1 = new Window();
		//Game execution
		while(previousPart != currentPart) {readPart(currentPart);}
		System.exit(1);
	}
}
