package main;
import java.util.ArrayList;
import java.util.List;

public class PartOfStory {
	private List <String> gameTexts;
	private String question;
	private List<Option> options;
	private PartOfStory directRef;
	private boolean end;
	
	public PartOfStory() {
		gameTexts = new ArrayList<String>();
		options = new ArrayList<Option>();
		directRef = null;
		end = false;
	}

	public List <String> getGameTexts() {
		return gameTexts;
	}

	public void addGameText(String gt) {
		gameTexts.add(gt);
	}

	public String getQuestion() {
		return question;
	}
	
	public void setQuestion(String question) {
		this.question = question;
	}

	public List<Option> getOptions() {
		return options;
	}

	public void addOption(String name, String content, PartOfStory ref) {
		options.add(new Option(name, content, ref));
	}
	
	public PartOfStory getRef(Option opt) {
		return opt.getRef();
	}

	public PartOfStory getDirectRef() {
		return directRef;
	}

	public void setDirectRef(PartOfStory directRef) {
		this.directRef = directRef;
	}

	public boolean isEnd() {
		return end;
	}

	public void setEnd() {
		this.end = true;
	}
}
