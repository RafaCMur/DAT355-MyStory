package main;

public class Leon_entrega_a_Edmund extends PartOfStory{
	
	public Leon_entrega_a_Edmund() {
		this.addGameText("Al entregar el le�n al chico, la profec�a de los cuatro tronos de Cair Paravel jam�s se hizo cierta");
		this.setDirectRef(new Has_perdido());
	}
}
