package main;

public class Aslan_Se_Entrega extends PartOfStory{

	public Aslan_Se_Entrega () {
		this.addGameText("La historia continuar�a aqu�...");
	}
}
