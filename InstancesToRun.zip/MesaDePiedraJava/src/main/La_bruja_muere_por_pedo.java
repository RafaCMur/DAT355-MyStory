package main;

public class La_bruja_muere_por_pedo extends PartOfStory{
	
	public La_bruja_muere_por_pedo () {
		this.addGameText("Aslan, el le�n, se tir� un pedo enorme que hizo perecer a la bruja.\n"
				+ "Fin.");
		this.setQuestion("Esto es demasiado para ti. Tienes que pegarte un tiro, no te queda otra");
		this.addOption("A", "Me pego un tiro", new Has_perdido());
	}
}
