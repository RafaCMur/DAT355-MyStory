package main;

import java.util.List;
import java.util.ArrayList;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Window extends JFrame implements ActionListener{

	private static final long serialVersionUID = 1L;
	
	private List <JButton> btns;
	private List <JLabel> labels;
	private JTextArea area;
	private JLabel question;
	private JScrollPane scroller;
	private int increment = 40;
	private Color btnColor = new Color(230, 230, 230);
	private Font font;

	public Window() {
		this.setSize(1500, 800);
		this.setLayout(null);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setTitle("My Story"); //TODO poner t�tulo desde el dsl
		this.setLocationRelativeTo(null);
		this.getContentPane().setBackground(Color.WHITE); //new Color(255, 250, 242)
		initComponents();
		init();
		this.setVisible(true);
	}
	
	private void initComponents () {
		question = new JLabel();
		btns = new ArrayList<JButton>();
		labels = new ArrayList<JLabel>();
		area = new JTextArea();
		scroller = new JScrollPane(area);
		font = new Font("Monaco", Font.BOLD, 20);
	}
	
	private void initArea() {
		area.setBounds(10, 10, 1460, 500);
		area.setLineWrap(true);
		area.setWrapStyleWord(true);
	    area.setEditable(false);
	    area.setFocusable(false);
	}
	
	private void initQuestion() {
		question.setBounds(10, 520, 1460, 30);
		question.setFont(font);
		this.add(question);
	}
	
	public void setQuestion(String q) {
		question.setText(q);
	}
	
	public void addTextToArea(String text) {
		area.append(text);
	}
	
	public void addNewButton(String id, String text) {
		JButton btn = new JButton(id);
		JLabel lbl = new JLabel(text);
		btns.add(btn);
		labels.add(lbl);
		int i = btns.indexOf(btn);
		btn.addActionListener(this);
		btn.setBounds(10, 560 + i*increment, 30, 20);
		btn.setBorder(BorderFactory.createEmptyBorder());
		btn.setBackground(btnColor);
		lbl.setBounds(70, 560 + i*increment, 1400, 20);
	}
	
	public void refreshButtons() {
		btns.forEach(btn -> this.add(btn));
		labels.forEach(lbl -> this.add(lbl));
		this.repaint();
	}
	
	public void addContinue() {
		JButton btn = new JButton("Continue");
		btn.addActionListener(this);
		btn.setBounds(10, 560, 100, 25);
		btn.setBorder(BorderFactory.createEmptyBorder());
		btn.setBackground(btnColor);
		btns.add(btn);
	}
	
	public List<JButton> getBtns() {
		return btns;
	}
	
	private void init() {
		
		initArea();
	    scroller.setBounds(10, 10, 1460, 500);
	    initQuestion();
		
		this.add(scroller);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if("Continue" == (String) ((AbstractButton) e.getSource()).getText()) {
			Main._continue = "Continue";
		} else {
			Main.sharedOpt = (String) ((AbstractButton) e.getSource()).getText();	
		}
	}

	public void clearAll() {
		area.setText("");
		question.setText("");
		btns.forEach(btn -> this.remove(btn));
		btns.clear();
		labels.forEach(lbl -> this.remove(lbl));
		labels.clear();
		this.repaint();
		//SwingUtilities.updateComponentTreeUI(this); //This works like repaint but gives an exception
	}
}
