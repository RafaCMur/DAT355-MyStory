package org.story.dsl.generator;

import com.google.common.collect.Iterables;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.generator.IFileSystemAccess2;
import org.eclipse.xtext.xbase.lib.IteratorExtensions;
import org.story.dsl.dSL.GameText;
import org.story.dsl.dSL.GoTo;
import org.story.dsl.dSL.Option;
import org.story.dsl.dSL.Options;
import org.story.dsl.dSL.PartOfStory;
import org.story.dsl.dSL.Question;

@SuppressWarnings("all")
public class Harcodings {
  public static void compile(final Resource resource, final IFileSystemAccess2 fsa) {
    Iterable<PartOfStory> _filter = Iterables.<PartOfStory>filter(IteratorExtensions.<EObject>toIterable(resource.getAllContents()), PartOfStory.class);
    for (final PartOfStory part : _filter) {
      String _name = part.getName();
      String _plus = (_name + ".java");
      fsa.generateFile(_plus, Harcodings.compilePart(part));
    }
  }
  
  /**
   * This method will reformat the string in such a way that when it is generated in a java file, there are no
   * problems with multiline strings, because Java does not support them.
   */
  private static String multiLine(final String str) {
    return str.replaceAll(System.getProperty("line.separator"), "\"\n+ \"");
  }
  
  private static CharSequence compilePart(final PartOfStory part) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("public class ");
    String _name = part.getName();
    _builder.append(_name);
    _builder.append(" extends PartOfStory{");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("public ");
    String _name_1 = part.getName();
    _builder.append(_name_1, "\t");
    _builder.append("() {");
    _builder.newLineIfNotEmpty();
    {
      boolean _isEmpty = part.getGameTexts().isEmpty();
      boolean _not = (!_isEmpty);
      if (_not) {
        {
          EList<GameText> _gameTexts = part.getGameTexts();
          for(final GameText gt : _gameTexts) {
            _builder.append("\t\t");
            _builder.append("this.addGameText(\"");
            String _multiLine = Harcodings.multiLine(gt.getContent());
            _builder.append(_multiLine, "\t\t");
            _builder.append("\");");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    {
      Question _question = part.getQuestion();
      boolean _tripleNotEquals = (_question != null);
      if (_tripleNotEquals) {
        _builder.append("\t\t");
        _builder.newLine();
        _builder.append("\t\t");
        _builder.append("this.setQuestion(\"");
        String _multiLine_1 = Harcodings.multiLine(part.getQuestion().getContent());
        _builder.append(_multiLine_1, "\t\t");
        _builder.append("\");");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      boolean _isEmpty_1 = part.getAllOptions().isEmpty();
      boolean _not_1 = (!_isEmpty_1);
      if (_not_1) {
        _builder.append("\t\t");
        _builder.newLine();
        {
          EList<Options> _allOptions = part.getAllOptions();
          for(final Options opts : _allOptions) {
            {
              EList<Option> _options = opts.getOptions();
              for(final Option opt : _options) {
                _builder.append("\t\t");
                _builder.append("this.addOption(\"");
                String _name_2 = opt.getName();
                _builder.append(_name_2, "\t\t");
                _builder.append("\", \"");
                String _multiLine_2 = Harcodings.multiLine(opt.getContent());
                _builder.append(_multiLine_2, "\t\t");
                _builder.append("\", new ");
                String _name_3 = opt.getGoto().getNextPart().getName();
                _builder.append(_name_3, "\t\t");
                _builder.append("());");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
      }
    }
    {
      GoTo _goto = part.getGoto();
      boolean _tripleNotEquals_1 = (_goto != null);
      if (_tripleNotEquals_1) {
        _builder.newLine();
        _builder.append("\t\t");
        _builder.append("this.setDirectRef(new ");
        String _name_4 = part.getGoto().getNextPart().getName();
        _builder.append(_name_4, "\t\t");
        _builder.append("());");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("}");
    _builder.newLine();
    return _builder;
  }
}
