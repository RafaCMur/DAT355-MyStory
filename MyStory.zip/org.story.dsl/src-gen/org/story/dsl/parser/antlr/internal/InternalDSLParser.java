package org.story.dsl.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.story.dsl.services.DSLGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalDSLParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_START", "RULE_STRING", "RULE_OPT_ID", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'partOfStory'", "'{'", "'}'", "'<t>'", "'<?>'", "'<!>'", "','", "':'", "'---->'", "'_'"
    };
    public static final int RULE_START=4;
    public static final int RULE_STRING=5;
    public static final int RULE_SL_COMMENT=10;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int RULE_OPT_ID=6;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ID=7;
    public static final int RULE_WS=11;
    public static final int RULE_ANY_OTHER=12;
    public static final int RULE_INT=8;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=9;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalDSLParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalDSLParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalDSLParser.tokenNames; }
    public String getGrammarFileName() { return "InternalDSL.g"; }



     	private DSLGrammarAccess grammarAccess;

        public InternalDSLParser(TokenStream input, DSLGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Model";
       	}

       	@Override
       	protected DSLGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleModel"
    // InternalDSL.g:64:1: entryRuleModel returns [EObject current=null] : iv_ruleModel= ruleModel EOF ;
    public final EObject entryRuleModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModel = null;


        try {
            // InternalDSL.g:64:46: (iv_ruleModel= ruleModel EOF )
            // InternalDSL.g:65:2: iv_ruleModel= ruleModel EOF
            {
             newCompositeNode(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleModel=ruleModel();

            state._fsp--;

             current =iv_ruleModel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalDSL.g:71:1: ruleModel returns [EObject current=null] : ( (lv_elements_0_0= ruleAbstractElement ) )* ;
    public final EObject ruleModel() throws RecognitionException {
        EObject current = null;

        EObject lv_elements_0_0 = null;



        	enterRule();

        try {
            // InternalDSL.g:77:2: ( ( (lv_elements_0_0= ruleAbstractElement ) )* )
            // InternalDSL.g:78:2: ( (lv_elements_0_0= ruleAbstractElement ) )*
            {
            // InternalDSL.g:78:2: ( (lv_elements_0_0= ruleAbstractElement ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==13) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalDSL.g:79:3: (lv_elements_0_0= ruleAbstractElement )
            	    {
            	    // InternalDSL.g:79:3: (lv_elements_0_0= ruleAbstractElement )
            	    // InternalDSL.g:80:4: lv_elements_0_0= ruleAbstractElement
            	    {

            	    				newCompositeNode(grammarAccess.getModelAccess().getElementsAbstractElementParserRuleCall_0());
            	    			
            	    pushFollow(FOLLOW_3);
            	    lv_elements_0_0=ruleAbstractElement();

            	    state._fsp--;


            	    				if (current==null) {
            	    					current = createModelElementForParent(grammarAccess.getModelRule());
            	    				}
            	    				add(
            	    					current,
            	    					"elements",
            	    					lv_elements_0_0,
            	    					"org.story.dsl.DSL.AbstractElement");
            	    				afterParserOrEnumRuleCall();
            	    			

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleAbstractElement"
    // InternalDSL.g:100:1: entryRuleAbstractElement returns [EObject current=null] : iv_ruleAbstractElement= ruleAbstractElement EOF ;
    public final EObject entryRuleAbstractElement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAbstractElement = null;


        try {
            // InternalDSL.g:100:56: (iv_ruleAbstractElement= ruleAbstractElement EOF )
            // InternalDSL.g:101:2: iv_ruleAbstractElement= ruleAbstractElement EOF
            {
             newCompositeNode(grammarAccess.getAbstractElementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAbstractElement=ruleAbstractElement();

            state._fsp--;

             current =iv_ruleAbstractElement; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAbstractElement"


    // $ANTLR start "ruleAbstractElement"
    // InternalDSL.g:107:1: ruleAbstractElement returns [EObject current=null] : this_Story_0= ruleStory ;
    public final EObject ruleAbstractElement() throws RecognitionException {
        EObject current = null;

        EObject this_Story_0 = null;



        	enterRule();

        try {
            // InternalDSL.g:113:2: (this_Story_0= ruleStory )
            // InternalDSL.g:114:2: this_Story_0= ruleStory
            {

            		newCompositeNode(grammarAccess.getAbstractElementAccess().getStoryParserRuleCall());
            	
            pushFollow(FOLLOW_2);
            this_Story_0=ruleStory();

            state._fsp--;


            		current = this_Story_0;
            		afterParserOrEnumRuleCall();
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAbstractElement"


    // $ANTLR start "entryRuleStory"
    // InternalDSL.g:125:1: entryRuleStory returns [EObject current=null] : iv_ruleStory= ruleStory EOF ;
    public final EObject entryRuleStory() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStory = null;


        try {
            // InternalDSL.g:125:46: (iv_ruleStory= ruleStory EOF )
            // InternalDSL.g:126:2: iv_ruleStory= ruleStory EOF
            {
             newCompositeNode(grammarAccess.getStoryRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleStory=ruleStory();

            state._fsp--;

             current =iv_ruleStory; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStory"


    // $ANTLR start "ruleStory"
    // InternalDSL.g:132:1: ruleStory returns [EObject current=null] : ( (lv_stories_0_0= rulePartOfStory ) )+ ;
    public final EObject ruleStory() throws RecognitionException {
        EObject current = null;

        EObject lv_stories_0_0 = null;



        	enterRule();

        try {
            // InternalDSL.g:138:2: ( ( (lv_stories_0_0= rulePartOfStory ) )+ )
            // InternalDSL.g:139:2: ( (lv_stories_0_0= rulePartOfStory ) )+
            {
            // InternalDSL.g:139:2: ( (lv_stories_0_0= rulePartOfStory ) )+
            int cnt2=0;
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==13) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalDSL.g:140:3: (lv_stories_0_0= rulePartOfStory )
            	    {
            	    // InternalDSL.g:140:3: (lv_stories_0_0= rulePartOfStory )
            	    // InternalDSL.g:141:4: lv_stories_0_0= rulePartOfStory
            	    {

            	    				newCompositeNode(grammarAccess.getStoryAccess().getStoriesPartOfStoryParserRuleCall_0());
            	    			
            	    pushFollow(FOLLOW_3);
            	    lv_stories_0_0=rulePartOfStory();

            	    state._fsp--;


            	    				if (current==null) {
            	    					current = createModelElementForParent(grammarAccess.getStoryRule());
            	    				}
            	    				add(
            	    					current,
            	    					"stories",
            	    					lv_stories_0_0,
            	    					"org.story.dsl.DSL.PartOfStory");
            	    				afterParserOrEnumRuleCall();
            	    			

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt2 >= 1 ) break loop2;
                        EarlyExitException eee =
                            new EarlyExitException(2, input);
                        throw eee;
                }
                cnt2++;
            } while (true);


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStory"


    // $ANTLR start "entryRulePartOfStory"
    // InternalDSL.g:161:1: entryRulePartOfStory returns [EObject current=null] : iv_rulePartOfStory= rulePartOfStory EOF ;
    public final EObject entryRulePartOfStory() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePartOfStory = null;


        try {
            // InternalDSL.g:161:52: (iv_rulePartOfStory= rulePartOfStory EOF )
            // InternalDSL.g:162:2: iv_rulePartOfStory= rulePartOfStory EOF
            {
             newCompositeNode(grammarAccess.getPartOfStoryRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePartOfStory=rulePartOfStory();

            state._fsp--;

             current =iv_rulePartOfStory; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePartOfStory"


    // $ANTLR start "rulePartOfStory"
    // InternalDSL.g:168:1: rulePartOfStory returns [EObject current=null] : (otherlv_0= 'partOfStory' ( (lv_name_1_0= ruleNameWithUnderscore ) ) otherlv_2= '{' ( (lv_start_3_0= RULE_START ) )? ( (lv_gameTexts_4_0= ruleGameText ) )+ ( (lv_question_5_0= ruleQuestion ) )? ( ( (lv_allOptions_6_0= ruleOptions ) )* | ( (lv_goto_7_0= ruleGoTo ) )? ) otherlv_8= '}' ) ;
    public final EObject rulePartOfStory() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token lv_start_3_0=null;
        Token otherlv_8=null;
        AntlrDatatypeRuleToken lv_name_1_0 = null;

        EObject lv_gameTexts_4_0 = null;

        EObject lv_question_5_0 = null;

        EObject lv_allOptions_6_0 = null;

        EObject lv_goto_7_0 = null;



        	enterRule();

        try {
            // InternalDSL.g:174:2: ( (otherlv_0= 'partOfStory' ( (lv_name_1_0= ruleNameWithUnderscore ) ) otherlv_2= '{' ( (lv_start_3_0= RULE_START ) )? ( (lv_gameTexts_4_0= ruleGameText ) )+ ( (lv_question_5_0= ruleQuestion ) )? ( ( (lv_allOptions_6_0= ruleOptions ) )* | ( (lv_goto_7_0= ruleGoTo ) )? ) otherlv_8= '}' ) )
            // InternalDSL.g:175:2: (otherlv_0= 'partOfStory' ( (lv_name_1_0= ruleNameWithUnderscore ) ) otherlv_2= '{' ( (lv_start_3_0= RULE_START ) )? ( (lv_gameTexts_4_0= ruleGameText ) )+ ( (lv_question_5_0= ruleQuestion ) )? ( ( (lv_allOptions_6_0= ruleOptions ) )* | ( (lv_goto_7_0= ruleGoTo ) )? ) otherlv_8= '}' )
            {
            // InternalDSL.g:175:2: (otherlv_0= 'partOfStory' ( (lv_name_1_0= ruleNameWithUnderscore ) ) otherlv_2= '{' ( (lv_start_3_0= RULE_START ) )? ( (lv_gameTexts_4_0= ruleGameText ) )+ ( (lv_question_5_0= ruleQuestion ) )? ( ( (lv_allOptions_6_0= ruleOptions ) )* | ( (lv_goto_7_0= ruleGoTo ) )? ) otherlv_8= '}' )
            // InternalDSL.g:176:3: otherlv_0= 'partOfStory' ( (lv_name_1_0= ruleNameWithUnderscore ) ) otherlv_2= '{' ( (lv_start_3_0= RULE_START ) )? ( (lv_gameTexts_4_0= ruleGameText ) )+ ( (lv_question_5_0= ruleQuestion ) )? ( ( (lv_allOptions_6_0= ruleOptions ) )* | ( (lv_goto_7_0= ruleGoTo ) )? ) otherlv_8= '}'
            {
            otherlv_0=(Token)match(input,13,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getPartOfStoryAccess().getPartOfStoryKeyword_0());
            		
            // InternalDSL.g:180:3: ( (lv_name_1_0= ruleNameWithUnderscore ) )
            // InternalDSL.g:181:4: (lv_name_1_0= ruleNameWithUnderscore )
            {
            // InternalDSL.g:181:4: (lv_name_1_0= ruleNameWithUnderscore )
            // InternalDSL.g:182:5: lv_name_1_0= ruleNameWithUnderscore
            {

            					newCompositeNode(grammarAccess.getPartOfStoryAccess().getNameNameWithUnderscoreParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_5);
            lv_name_1_0=ruleNameWithUnderscore();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPartOfStoryRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.story.dsl.DSL.NameWithUnderscore");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getPartOfStoryAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalDSL.g:203:3: ( (lv_start_3_0= RULE_START ) )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==RULE_START) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // InternalDSL.g:204:4: (lv_start_3_0= RULE_START )
                    {
                    // InternalDSL.g:204:4: (lv_start_3_0= RULE_START )
                    // InternalDSL.g:205:5: lv_start_3_0= RULE_START
                    {
                    lv_start_3_0=(Token)match(input,RULE_START,FOLLOW_6); 

                    					newLeafNode(lv_start_3_0, grammarAccess.getPartOfStoryAccess().getStartSTARTTerminalRuleCall_3_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getPartOfStoryRule());
                    					}
                    					setWithLastConsumed(
                    						current,
                    						"start",
                    						lv_start_3_0,
                    						"org.story.dsl.DSL.START");
                    				

                    }


                    }
                    break;

            }

            // InternalDSL.g:221:3: ( (lv_gameTexts_4_0= ruleGameText ) )+
            int cnt4=0;
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==16) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalDSL.g:222:4: (lv_gameTexts_4_0= ruleGameText )
            	    {
            	    // InternalDSL.g:222:4: (lv_gameTexts_4_0= ruleGameText )
            	    // InternalDSL.g:223:5: lv_gameTexts_4_0= ruleGameText
            	    {

            	    					newCompositeNode(grammarAccess.getPartOfStoryAccess().getGameTextsGameTextParserRuleCall_4_0());
            	    				
            	    pushFollow(FOLLOW_7);
            	    lv_gameTexts_4_0=ruleGameText();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getPartOfStoryRule());
            	    					}
            	    					add(
            	    						current,
            	    						"gameTexts",
            	    						lv_gameTexts_4_0,
            	    						"org.story.dsl.DSL.GameText");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt4 >= 1 ) break loop4;
                        EarlyExitException eee =
                            new EarlyExitException(4, input);
                        throw eee;
                }
                cnt4++;
            } while (true);

            // InternalDSL.g:240:3: ( (lv_question_5_0= ruleQuestion ) )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==17) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalDSL.g:241:4: (lv_question_5_0= ruleQuestion )
                    {
                    // InternalDSL.g:241:4: (lv_question_5_0= ruleQuestion )
                    // InternalDSL.g:242:5: lv_question_5_0= ruleQuestion
                    {

                    					newCompositeNode(grammarAccess.getPartOfStoryAccess().getQuestionQuestionParserRuleCall_5_0());
                    				
                    pushFollow(FOLLOW_8);
                    lv_question_5_0=ruleQuestion();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPartOfStoryRule());
                    					}
                    					set(
                    						current,
                    						"question",
                    						lv_question_5_0,
                    						"org.story.dsl.DSL.Question");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalDSL.g:259:3: ( ( (lv_allOptions_6_0= ruleOptions ) )* | ( (lv_goto_7_0= ruleGoTo ) )? )
            int alt8=2;
            switch ( input.LA(1) ) {
            case 18:
                {
                alt8=1;
                }
                break;
            case 15:
                {
                alt8=1;
                }
                break;
            case 21:
                {
                alt8=2;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }

            switch (alt8) {
                case 1 :
                    // InternalDSL.g:260:4: ( (lv_allOptions_6_0= ruleOptions ) )*
                    {
                    // InternalDSL.g:260:4: ( (lv_allOptions_6_0= ruleOptions ) )*
                    loop6:
                    do {
                        int alt6=2;
                        int LA6_0 = input.LA(1);

                        if ( (LA6_0==18) ) {
                            alt6=1;
                        }


                        switch (alt6) {
                    	case 1 :
                    	    // InternalDSL.g:261:5: (lv_allOptions_6_0= ruleOptions )
                    	    {
                    	    // InternalDSL.g:261:5: (lv_allOptions_6_0= ruleOptions )
                    	    // InternalDSL.g:262:6: lv_allOptions_6_0= ruleOptions
                    	    {

                    	    						newCompositeNode(grammarAccess.getPartOfStoryAccess().getAllOptionsOptionsParserRuleCall_6_0_0());
                    	    					
                    	    pushFollow(FOLLOW_9);
                    	    lv_allOptions_6_0=ruleOptions();

                    	    state._fsp--;


                    	    						if (current==null) {
                    	    							current = createModelElementForParent(grammarAccess.getPartOfStoryRule());
                    	    						}
                    	    						add(
                    	    							current,
                    	    							"allOptions",
                    	    							lv_allOptions_6_0,
                    	    							"org.story.dsl.DSL.Options");
                    	    						afterParserOrEnumRuleCall();
                    	    					

                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop6;
                        }
                    } while (true);


                    }
                    break;
                case 2 :
                    // InternalDSL.g:280:4: ( (lv_goto_7_0= ruleGoTo ) )?
                    {
                    // InternalDSL.g:280:4: ( (lv_goto_7_0= ruleGoTo ) )?
                    int alt7=2;
                    int LA7_0 = input.LA(1);

                    if ( (LA7_0==21) ) {
                        alt7=1;
                    }
                    switch (alt7) {
                        case 1 :
                            // InternalDSL.g:281:5: (lv_goto_7_0= ruleGoTo )
                            {
                            // InternalDSL.g:281:5: (lv_goto_7_0= ruleGoTo )
                            // InternalDSL.g:282:6: lv_goto_7_0= ruleGoTo
                            {

                            						newCompositeNode(grammarAccess.getPartOfStoryAccess().getGotoGoToParserRuleCall_6_1_0());
                            					
                            pushFollow(FOLLOW_10);
                            lv_goto_7_0=ruleGoTo();

                            state._fsp--;


                            						if (current==null) {
                            							current = createModelElementForParent(grammarAccess.getPartOfStoryRule());
                            						}
                            						set(
                            							current,
                            							"goto",
                            							lv_goto_7_0,
                            							"org.story.dsl.DSL.GoTo");
                            						afterParserOrEnumRuleCall();
                            					

                            }


                            }
                            break;

                    }


                    }
                    break;

            }

            otherlv_8=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_8, grammarAccess.getPartOfStoryAccess().getRightCurlyBracketKeyword_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePartOfStory"


    // $ANTLR start "entryRuleGameText"
    // InternalDSL.g:308:1: entryRuleGameText returns [EObject current=null] : iv_ruleGameText= ruleGameText EOF ;
    public final EObject entryRuleGameText() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleGameText = null;


        try {
            // InternalDSL.g:308:49: (iv_ruleGameText= ruleGameText EOF )
            // InternalDSL.g:309:2: iv_ruleGameText= ruleGameText EOF
            {
             newCompositeNode(grammarAccess.getGameTextRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleGameText=ruleGameText();

            state._fsp--;

             current =iv_ruleGameText; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleGameText"


    // $ANTLR start "ruleGameText"
    // InternalDSL.g:315:1: ruleGameText returns [EObject current=null] : (otherlv_0= '<t>' ( (lv_content_1_0= RULE_STRING ) ) otherlv_2= '<t>' ) ;
    public final EObject ruleGameText() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_content_1_0=null;
        Token otherlv_2=null;


        	enterRule();

        try {
            // InternalDSL.g:321:2: ( (otherlv_0= '<t>' ( (lv_content_1_0= RULE_STRING ) ) otherlv_2= '<t>' ) )
            // InternalDSL.g:322:2: (otherlv_0= '<t>' ( (lv_content_1_0= RULE_STRING ) ) otherlv_2= '<t>' )
            {
            // InternalDSL.g:322:2: (otherlv_0= '<t>' ( (lv_content_1_0= RULE_STRING ) ) otherlv_2= '<t>' )
            // InternalDSL.g:323:3: otherlv_0= '<t>' ( (lv_content_1_0= RULE_STRING ) ) otherlv_2= '<t>'
            {
            otherlv_0=(Token)match(input,16,FOLLOW_11); 

            			newLeafNode(otherlv_0, grammarAccess.getGameTextAccess().getTKeyword_0());
            		
            // InternalDSL.g:327:3: ( (lv_content_1_0= RULE_STRING ) )
            // InternalDSL.g:328:4: (lv_content_1_0= RULE_STRING )
            {
            // InternalDSL.g:328:4: (lv_content_1_0= RULE_STRING )
            // InternalDSL.g:329:5: lv_content_1_0= RULE_STRING
            {
            lv_content_1_0=(Token)match(input,RULE_STRING,FOLLOW_12); 

            					newLeafNode(lv_content_1_0, grammarAccess.getGameTextAccess().getContentSTRINGTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getGameTextRule());
            					}
            					setWithLastConsumed(
            						current,
            						"content",
            						lv_content_1_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_2=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_2, grammarAccess.getGameTextAccess().getTKeyword_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleGameText"


    // $ANTLR start "entryRuleQuestion"
    // InternalDSL.g:353:1: entryRuleQuestion returns [EObject current=null] : iv_ruleQuestion= ruleQuestion EOF ;
    public final EObject entryRuleQuestion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleQuestion = null;


        try {
            // InternalDSL.g:353:49: (iv_ruleQuestion= ruleQuestion EOF )
            // InternalDSL.g:354:2: iv_ruleQuestion= ruleQuestion EOF
            {
             newCompositeNode(grammarAccess.getQuestionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleQuestion=ruleQuestion();

            state._fsp--;

             current =iv_ruleQuestion; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleQuestion"


    // $ANTLR start "ruleQuestion"
    // InternalDSL.g:360:1: ruleQuestion returns [EObject current=null] : (otherlv_0= '<?>' ( (lv_content_1_0= RULE_STRING ) ) otherlv_2= '<?>' ) ;
    public final EObject ruleQuestion() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_content_1_0=null;
        Token otherlv_2=null;


        	enterRule();

        try {
            // InternalDSL.g:366:2: ( (otherlv_0= '<?>' ( (lv_content_1_0= RULE_STRING ) ) otherlv_2= '<?>' ) )
            // InternalDSL.g:367:2: (otherlv_0= '<?>' ( (lv_content_1_0= RULE_STRING ) ) otherlv_2= '<?>' )
            {
            // InternalDSL.g:367:2: (otherlv_0= '<?>' ( (lv_content_1_0= RULE_STRING ) ) otherlv_2= '<?>' )
            // InternalDSL.g:368:3: otherlv_0= '<?>' ( (lv_content_1_0= RULE_STRING ) ) otherlv_2= '<?>'
            {
            otherlv_0=(Token)match(input,17,FOLLOW_11); 

            			newLeafNode(otherlv_0, grammarAccess.getQuestionAccess().getLessThanSignQuestionMarkGreaterThanSignKeyword_0());
            		
            // InternalDSL.g:372:3: ( (lv_content_1_0= RULE_STRING ) )
            // InternalDSL.g:373:4: (lv_content_1_0= RULE_STRING )
            {
            // InternalDSL.g:373:4: (lv_content_1_0= RULE_STRING )
            // InternalDSL.g:374:5: lv_content_1_0= RULE_STRING
            {
            lv_content_1_0=(Token)match(input,RULE_STRING,FOLLOW_13); 

            					newLeafNode(lv_content_1_0, grammarAccess.getQuestionAccess().getContentSTRINGTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getQuestionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"content",
            						lv_content_1_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_2=(Token)match(input,17,FOLLOW_2); 

            			newLeafNode(otherlv_2, grammarAccess.getQuestionAccess().getLessThanSignQuestionMarkGreaterThanSignKeyword_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleQuestion"


    // $ANTLR start "entryRuleOptions"
    // InternalDSL.g:398:1: entryRuleOptions returns [EObject current=null] : iv_ruleOptions= ruleOptions EOF ;
    public final EObject entryRuleOptions() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOptions = null;


        try {
            // InternalDSL.g:398:48: (iv_ruleOptions= ruleOptions EOF )
            // InternalDSL.g:399:2: iv_ruleOptions= ruleOptions EOF
            {
             newCompositeNode(grammarAccess.getOptionsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOptions=ruleOptions();

            state._fsp--;

             current =iv_ruleOptions; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOptions"


    // $ANTLR start "ruleOptions"
    // InternalDSL.g:405:1: ruleOptions returns [EObject current=null] : (otherlv_0= '<!>' ( (lv_options_1_0= ruleOption ) ) (otherlv_2= ',' ( (lv_options_3_0= ruleOption ) ) )* otherlv_4= '<!>' ) ;
    public final EObject ruleOptions() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_options_1_0 = null;

        EObject lv_options_3_0 = null;



        	enterRule();

        try {
            // InternalDSL.g:411:2: ( (otherlv_0= '<!>' ( (lv_options_1_0= ruleOption ) ) (otherlv_2= ',' ( (lv_options_3_0= ruleOption ) ) )* otherlv_4= '<!>' ) )
            // InternalDSL.g:412:2: (otherlv_0= '<!>' ( (lv_options_1_0= ruleOption ) ) (otherlv_2= ',' ( (lv_options_3_0= ruleOption ) ) )* otherlv_4= '<!>' )
            {
            // InternalDSL.g:412:2: (otherlv_0= '<!>' ( (lv_options_1_0= ruleOption ) ) (otherlv_2= ',' ( (lv_options_3_0= ruleOption ) ) )* otherlv_4= '<!>' )
            // InternalDSL.g:413:3: otherlv_0= '<!>' ( (lv_options_1_0= ruleOption ) ) (otherlv_2= ',' ( (lv_options_3_0= ruleOption ) ) )* otherlv_4= '<!>'
            {
            otherlv_0=(Token)match(input,18,FOLLOW_14); 

            			newLeafNode(otherlv_0, grammarAccess.getOptionsAccess().getLessThanSignExclamationMarkGreaterThanSignKeyword_0());
            		
            // InternalDSL.g:417:3: ( (lv_options_1_0= ruleOption ) )
            // InternalDSL.g:418:4: (lv_options_1_0= ruleOption )
            {
            // InternalDSL.g:418:4: (lv_options_1_0= ruleOption )
            // InternalDSL.g:419:5: lv_options_1_0= ruleOption
            {

            					newCompositeNode(grammarAccess.getOptionsAccess().getOptionsOptionParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_15);
            lv_options_1_0=ruleOption();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getOptionsRule());
            					}
            					add(
            						current,
            						"options",
            						lv_options_1_0,
            						"org.story.dsl.DSL.Option");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalDSL.g:436:3: (otherlv_2= ',' ( (lv_options_3_0= ruleOption ) ) )*
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( (LA9_0==19) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // InternalDSL.g:437:4: otherlv_2= ',' ( (lv_options_3_0= ruleOption ) )
            	    {
            	    otherlv_2=(Token)match(input,19,FOLLOW_14); 

            	    				newLeafNode(otherlv_2, grammarAccess.getOptionsAccess().getCommaKeyword_2_0());
            	    			
            	    // InternalDSL.g:441:4: ( (lv_options_3_0= ruleOption ) )
            	    // InternalDSL.g:442:5: (lv_options_3_0= ruleOption )
            	    {
            	    // InternalDSL.g:442:5: (lv_options_3_0= ruleOption )
            	    // InternalDSL.g:443:6: lv_options_3_0= ruleOption
            	    {

            	    						newCompositeNode(grammarAccess.getOptionsAccess().getOptionsOptionParserRuleCall_2_1_0());
            	    					
            	    pushFollow(FOLLOW_15);
            	    lv_options_3_0=ruleOption();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getOptionsRule());
            	    						}
            	    						add(
            	    							current,
            	    							"options",
            	    							lv_options_3_0,
            	    							"org.story.dsl.DSL.Option");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);

            otherlv_4=(Token)match(input,18,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getOptionsAccess().getLessThanSignExclamationMarkGreaterThanSignKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOptions"


    // $ANTLR start "entryRuleOption"
    // InternalDSL.g:469:1: entryRuleOption returns [EObject current=null] : iv_ruleOption= ruleOption EOF ;
    public final EObject entryRuleOption() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOption = null;


        try {
            // InternalDSL.g:469:47: (iv_ruleOption= ruleOption EOF )
            // InternalDSL.g:470:2: iv_ruleOption= ruleOption EOF
            {
             newCompositeNode(grammarAccess.getOptionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOption=ruleOption();

            state._fsp--;

             current =iv_ruleOption; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOption"


    // $ANTLR start "ruleOption"
    // InternalDSL.g:476:1: ruleOption returns [EObject current=null] : ( ( (lv_name_0_0= RULE_OPT_ID ) ) otherlv_1= ':' ( (lv_content_2_0= RULE_STRING ) ) ( (lv_goto_3_0= ruleGoTo ) ) ) ;
    public final EObject ruleOption() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;
        Token otherlv_1=null;
        Token lv_content_2_0=null;
        EObject lv_goto_3_0 = null;



        	enterRule();

        try {
            // InternalDSL.g:482:2: ( ( ( (lv_name_0_0= RULE_OPT_ID ) ) otherlv_1= ':' ( (lv_content_2_0= RULE_STRING ) ) ( (lv_goto_3_0= ruleGoTo ) ) ) )
            // InternalDSL.g:483:2: ( ( (lv_name_0_0= RULE_OPT_ID ) ) otherlv_1= ':' ( (lv_content_2_0= RULE_STRING ) ) ( (lv_goto_3_0= ruleGoTo ) ) )
            {
            // InternalDSL.g:483:2: ( ( (lv_name_0_0= RULE_OPT_ID ) ) otherlv_1= ':' ( (lv_content_2_0= RULE_STRING ) ) ( (lv_goto_3_0= ruleGoTo ) ) )
            // InternalDSL.g:484:3: ( (lv_name_0_0= RULE_OPT_ID ) ) otherlv_1= ':' ( (lv_content_2_0= RULE_STRING ) ) ( (lv_goto_3_0= ruleGoTo ) )
            {
            // InternalDSL.g:484:3: ( (lv_name_0_0= RULE_OPT_ID ) )
            // InternalDSL.g:485:4: (lv_name_0_0= RULE_OPT_ID )
            {
            // InternalDSL.g:485:4: (lv_name_0_0= RULE_OPT_ID )
            // InternalDSL.g:486:5: lv_name_0_0= RULE_OPT_ID
            {
            lv_name_0_0=(Token)match(input,RULE_OPT_ID,FOLLOW_16); 

            					newLeafNode(lv_name_0_0, grammarAccess.getOptionAccess().getNameOPT_IDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getOptionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_0_0,
            						"org.story.dsl.DSL.OPT_ID");
            				

            }


            }

            otherlv_1=(Token)match(input,20,FOLLOW_11); 

            			newLeafNode(otherlv_1, grammarAccess.getOptionAccess().getColonKeyword_1());
            		
            // InternalDSL.g:506:3: ( (lv_content_2_0= RULE_STRING ) )
            // InternalDSL.g:507:4: (lv_content_2_0= RULE_STRING )
            {
            // InternalDSL.g:507:4: (lv_content_2_0= RULE_STRING )
            // InternalDSL.g:508:5: lv_content_2_0= RULE_STRING
            {
            lv_content_2_0=(Token)match(input,RULE_STRING,FOLLOW_17); 

            					newLeafNode(lv_content_2_0, grammarAccess.getOptionAccess().getContentSTRINGTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getOptionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"content",
            						lv_content_2_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalDSL.g:524:3: ( (lv_goto_3_0= ruleGoTo ) )
            // InternalDSL.g:525:4: (lv_goto_3_0= ruleGoTo )
            {
            // InternalDSL.g:525:4: (lv_goto_3_0= ruleGoTo )
            // InternalDSL.g:526:5: lv_goto_3_0= ruleGoTo
            {

            					newCompositeNode(grammarAccess.getOptionAccess().getGotoGoToParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_2);
            lv_goto_3_0=ruleGoTo();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getOptionRule());
            					}
            					set(
            						current,
            						"goto",
            						lv_goto_3_0,
            						"org.story.dsl.DSL.GoTo");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOption"


    // $ANTLR start "entryRuleGoTo"
    // InternalDSL.g:547:1: entryRuleGoTo returns [EObject current=null] : iv_ruleGoTo= ruleGoTo EOF ;
    public final EObject entryRuleGoTo() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleGoTo = null;


        try {
            // InternalDSL.g:547:45: (iv_ruleGoTo= ruleGoTo EOF )
            // InternalDSL.g:548:2: iv_ruleGoTo= ruleGoTo EOF
            {
             newCompositeNode(grammarAccess.getGoToRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleGoTo=ruleGoTo();

            state._fsp--;

             current =iv_ruleGoTo; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleGoTo"


    // $ANTLR start "ruleGoTo"
    // InternalDSL.g:554:1: ruleGoTo returns [EObject current=null] : (otherlv_0= '---->' ( (otherlv_1= RULE_ID ) ) ) ;
    public final EObject ruleGoTo() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;


        	enterRule();

        try {
            // InternalDSL.g:560:2: ( (otherlv_0= '---->' ( (otherlv_1= RULE_ID ) ) ) )
            // InternalDSL.g:561:2: (otherlv_0= '---->' ( (otherlv_1= RULE_ID ) ) )
            {
            // InternalDSL.g:561:2: (otherlv_0= '---->' ( (otherlv_1= RULE_ID ) ) )
            // InternalDSL.g:562:3: otherlv_0= '---->' ( (otherlv_1= RULE_ID ) )
            {
            otherlv_0=(Token)match(input,21,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getGoToAccess().getHyphenMinusHyphenMinusHyphenMinusHyphenMinusGreaterThanSignKeyword_0());
            		
            // InternalDSL.g:566:3: ( (otherlv_1= RULE_ID ) )
            // InternalDSL.g:567:4: (otherlv_1= RULE_ID )
            {
            // InternalDSL.g:567:4: (otherlv_1= RULE_ID )
            // InternalDSL.g:568:5: otherlv_1= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getGoToRule());
            					}
            				
            otherlv_1=(Token)match(input,RULE_ID,FOLLOW_2); 

            					newLeafNode(otherlv_1, grammarAccess.getGoToAccess().getNextPartPartOfStoryCrossReference_1_0());
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleGoTo"


    // $ANTLR start "entryRuleNameWithUnderscore"
    // InternalDSL.g:583:1: entryRuleNameWithUnderscore returns [String current=null] : iv_ruleNameWithUnderscore= ruleNameWithUnderscore EOF ;
    public final String entryRuleNameWithUnderscore() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleNameWithUnderscore = null;


        try {
            // InternalDSL.g:583:58: (iv_ruleNameWithUnderscore= ruleNameWithUnderscore EOF )
            // InternalDSL.g:584:2: iv_ruleNameWithUnderscore= ruleNameWithUnderscore EOF
            {
             newCompositeNode(grammarAccess.getNameWithUnderscoreRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNameWithUnderscore=ruleNameWithUnderscore();

            state._fsp--;

             current =iv_ruleNameWithUnderscore.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNameWithUnderscore"


    // $ANTLR start "ruleNameWithUnderscore"
    // InternalDSL.g:590:1: ruleNameWithUnderscore returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_ID_0= RULE_ID (kw= '_' this_ID_2= RULE_ID )* ) ;
    public final AntlrDatatypeRuleToken ruleNameWithUnderscore() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_ID_0=null;
        Token kw=null;
        Token this_ID_2=null;


        	enterRule();

        try {
            // InternalDSL.g:596:2: ( (this_ID_0= RULE_ID (kw= '_' this_ID_2= RULE_ID )* ) )
            // InternalDSL.g:597:2: (this_ID_0= RULE_ID (kw= '_' this_ID_2= RULE_ID )* )
            {
            // InternalDSL.g:597:2: (this_ID_0= RULE_ID (kw= '_' this_ID_2= RULE_ID )* )
            // InternalDSL.g:598:3: this_ID_0= RULE_ID (kw= '_' this_ID_2= RULE_ID )*
            {
            this_ID_0=(Token)match(input,RULE_ID,FOLLOW_18); 

            			current.merge(this_ID_0);
            		

            			newLeafNode(this_ID_0, grammarAccess.getNameWithUnderscoreAccess().getIDTerminalRuleCall_0());
            		
            // InternalDSL.g:605:3: (kw= '_' this_ID_2= RULE_ID )*
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( (LA10_0==22) ) {
                    alt10=1;
                }


                switch (alt10) {
            	case 1 :
            	    // InternalDSL.g:606:4: kw= '_' this_ID_2= RULE_ID
            	    {
            	    kw=(Token)match(input,22,FOLLOW_4); 

            	    				current.merge(kw);
            	    				newLeafNode(kw, grammarAccess.getNameWithUnderscoreAccess().get_Keyword_1_0());
            	    			
            	    this_ID_2=(Token)match(input,RULE_ID,FOLLOW_18); 

            	    				current.merge(this_ID_2);
            	    			

            	    				newLeafNode(this_ID_2, grammarAccess.getNameWithUnderscoreAccess().getIDTerminalRuleCall_1_1());
            	    			

            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNameWithUnderscore"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000002002L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000010010L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000278010L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000248000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000048000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x00000000000C0000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000400002L});

}