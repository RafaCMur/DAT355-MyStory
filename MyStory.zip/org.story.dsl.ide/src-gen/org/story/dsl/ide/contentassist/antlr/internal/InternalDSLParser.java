package org.story.dsl.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import org.story.dsl.services.DSLGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalDSLParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_START", "RULE_STRING", "RULE_OPT_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'partOfStory'", "'{'", "'}'", "'<t>'", "'<?>'", "'<!>'", "','", "':'", "'---->'", "'_'"
    };
    public static final int RULE_START=5;
    public static final int RULE_STRING=6;
    public static final int RULE_SL_COMMENT=10;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int RULE_OPT_ID=7;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ID=4;
    public static final int RULE_WS=11;
    public static final int RULE_ANY_OTHER=12;
    public static final int RULE_INT=8;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=9;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalDSLParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalDSLParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalDSLParser.tokenNames; }
    public String getGrammarFileName() { return "InternalDSL.g"; }


    	private DSLGrammarAccess grammarAccess;

    	public void setGrammarAccess(DSLGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleModel"
    // InternalDSL.g:53:1: entryRuleModel : ruleModel EOF ;
    public final void entryRuleModel() throws RecognitionException {
        try {
            // InternalDSL.g:54:1: ( ruleModel EOF )
            // InternalDSL.g:55:1: ruleModel EOF
            {
             before(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            ruleModel();

            state._fsp--;

             after(grammarAccess.getModelRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalDSL.g:62:1: ruleModel : ( ( rule__Model__ElementsAssignment )* ) ;
    public final void ruleModel() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:66:2: ( ( ( rule__Model__ElementsAssignment )* ) )
            // InternalDSL.g:67:2: ( ( rule__Model__ElementsAssignment )* )
            {
            // InternalDSL.g:67:2: ( ( rule__Model__ElementsAssignment )* )
            // InternalDSL.g:68:3: ( rule__Model__ElementsAssignment )*
            {
             before(grammarAccess.getModelAccess().getElementsAssignment()); 
            // InternalDSL.g:69:3: ( rule__Model__ElementsAssignment )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==13) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalDSL.g:69:4: rule__Model__ElementsAssignment
            	    {
            	    pushFollow(FOLLOW_3);
            	    rule__Model__ElementsAssignment();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

             after(grammarAccess.getModelAccess().getElementsAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleAbstractElement"
    // InternalDSL.g:78:1: entryRuleAbstractElement : ruleAbstractElement EOF ;
    public final void entryRuleAbstractElement() throws RecognitionException {
        try {
            // InternalDSL.g:79:1: ( ruleAbstractElement EOF )
            // InternalDSL.g:80:1: ruleAbstractElement EOF
            {
             before(grammarAccess.getAbstractElementRule()); 
            pushFollow(FOLLOW_1);
            ruleAbstractElement();

            state._fsp--;

             after(grammarAccess.getAbstractElementRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAbstractElement"


    // $ANTLR start "ruleAbstractElement"
    // InternalDSL.g:87:1: ruleAbstractElement : ( ruleStory ) ;
    public final void ruleAbstractElement() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:91:2: ( ( ruleStory ) )
            // InternalDSL.g:92:2: ( ruleStory )
            {
            // InternalDSL.g:92:2: ( ruleStory )
            // InternalDSL.g:93:3: ruleStory
            {
             before(grammarAccess.getAbstractElementAccess().getStoryParserRuleCall()); 
            pushFollow(FOLLOW_2);
            ruleStory();

            state._fsp--;

             after(grammarAccess.getAbstractElementAccess().getStoryParserRuleCall()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAbstractElement"


    // $ANTLR start "entryRuleStory"
    // InternalDSL.g:103:1: entryRuleStory : ruleStory EOF ;
    public final void entryRuleStory() throws RecognitionException {
        try {
            // InternalDSL.g:104:1: ( ruleStory EOF )
            // InternalDSL.g:105:1: ruleStory EOF
            {
             before(grammarAccess.getStoryRule()); 
            pushFollow(FOLLOW_1);
            ruleStory();

            state._fsp--;

             after(grammarAccess.getStoryRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleStory"


    // $ANTLR start "ruleStory"
    // InternalDSL.g:112:1: ruleStory : ( ( ( rule__Story__StoriesAssignment ) ) ( ( rule__Story__StoriesAssignment )* ) ) ;
    public final void ruleStory() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:116:2: ( ( ( ( rule__Story__StoriesAssignment ) ) ( ( rule__Story__StoriesAssignment )* ) ) )
            // InternalDSL.g:117:2: ( ( ( rule__Story__StoriesAssignment ) ) ( ( rule__Story__StoriesAssignment )* ) )
            {
            // InternalDSL.g:117:2: ( ( ( rule__Story__StoriesAssignment ) ) ( ( rule__Story__StoriesAssignment )* ) )
            // InternalDSL.g:118:3: ( ( rule__Story__StoriesAssignment ) ) ( ( rule__Story__StoriesAssignment )* )
            {
            // InternalDSL.g:118:3: ( ( rule__Story__StoriesAssignment ) )
            // InternalDSL.g:119:4: ( rule__Story__StoriesAssignment )
            {
             before(grammarAccess.getStoryAccess().getStoriesAssignment()); 
            // InternalDSL.g:120:4: ( rule__Story__StoriesAssignment )
            // InternalDSL.g:120:5: rule__Story__StoriesAssignment
            {
            pushFollow(FOLLOW_4);
            rule__Story__StoriesAssignment();

            state._fsp--;


            }

             after(grammarAccess.getStoryAccess().getStoriesAssignment()); 

            }

            // InternalDSL.g:123:3: ( ( rule__Story__StoriesAssignment )* )
            // InternalDSL.g:124:4: ( rule__Story__StoriesAssignment )*
            {
             before(grammarAccess.getStoryAccess().getStoriesAssignment()); 
            // InternalDSL.g:125:4: ( rule__Story__StoriesAssignment )*
            loop2:
            do {
                int alt2=2;
                alt2 = dfa2.predict(input);
                switch (alt2) {
            	case 1 :
            	    // InternalDSL.g:125:5: rule__Story__StoriesAssignment
            	    {
            	    pushFollow(FOLLOW_3);
            	    rule__Story__StoriesAssignment();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

             after(grammarAccess.getStoryAccess().getStoriesAssignment()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleStory"


    // $ANTLR start "entryRulePartOfStory"
    // InternalDSL.g:135:1: entryRulePartOfStory : rulePartOfStory EOF ;
    public final void entryRulePartOfStory() throws RecognitionException {
        try {
            // InternalDSL.g:136:1: ( rulePartOfStory EOF )
            // InternalDSL.g:137:1: rulePartOfStory EOF
            {
             before(grammarAccess.getPartOfStoryRule()); 
            pushFollow(FOLLOW_1);
            rulePartOfStory();

            state._fsp--;

             after(grammarAccess.getPartOfStoryRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePartOfStory"


    // $ANTLR start "rulePartOfStory"
    // InternalDSL.g:144:1: rulePartOfStory : ( ( rule__PartOfStory__Group__0 ) ) ;
    public final void rulePartOfStory() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:148:2: ( ( ( rule__PartOfStory__Group__0 ) ) )
            // InternalDSL.g:149:2: ( ( rule__PartOfStory__Group__0 ) )
            {
            // InternalDSL.g:149:2: ( ( rule__PartOfStory__Group__0 ) )
            // InternalDSL.g:150:3: ( rule__PartOfStory__Group__0 )
            {
             before(grammarAccess.getPartOfStoryAccess().getGroup()); 
            // InternalDSL.g:151:3: ( rule__PartOfStory__Group__0 )
            // InternalDSL.g:151:4: rule__PartOfStory__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__PartOfStory__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getPartOfStoryAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePartOfStory"


    // $ANTLR start "entryRuleGameText"
    // InternalDSL.g:160:1: entryRuleGameText : ruleGameText EOF ;
    public final void entryRuleGameText() throws RecognitionException {
        try {
            // InternalDSL.g:161:1: ( ruleGameText EOF )
            // InternalDSL.g:162:1: ruleGameText EOF
            {
             before(grammarAccess.getGameTextRule()); 
            pushFollow(FOLLOW_1);
            ruleGameText();

            state._fsp--;

             after(grammarAccess.getGameTextRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleGameText"


    // $ANTLR start "ruleGameText"
    // InternalDSL.g:169:1: ruleGameText : ( ( rule__GameText__Group__0 ) ) ;
    public final void ruleGameText() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:173:2: ( ( ( rule__GameText__Group__0 ) ) )
            // InternalDSL.g:174:2: ( ( rule__GameText__Group__0 ) )
            {
            // InternalDSL.g:174:2: ( ( rule__GameText__Group__0 ) )
            // InternalDSL.g:175:3: ( rule__GameText__Group__0 )
            {
             before(grammarAccess.getGameTextAccess().getGroup()); 
            // InternalDSL.g:176:3: ( rule__GameText__Group__0 )
            // InternalDSL.g:176:4: rule__GameText__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__GameText__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getGameTextAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleGameText"


    // $ANTLR start "entryRuleQuestion"
    // InternalDSL.g:185:1: entryRuleQuestion : ruleQuestion EOF ;
    public final void entryRuleQuestion() throws RecognitionException {
        try {
            // InternalDSL.g:186:1: ( ruleQuestion EOF )
            // InternalDSL.g:187:1: ruleQuestion EOF
            {
             before(grammarAccess.getQuestionRule()); 
            pushFollow(FOLLOW_1);
            ruleQuestion();

            state._fsp--;

             after(grammarAccess.getQuestionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleQuestion"


    // $ANTLR start "ruleQuestion"
    // InternalDSL.g:194:1: ruleQuestion : ( ( rule__Question__Group__0 ) ) ;
    public final void ruleQuestion() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:198:2: ( ( ( rule__Question__Group__0 ) ) )
            // InternalDSL.g:199:2: ( ( rule__Question__Group__0 ) )
            {
            // InternalDSL.g:199:2: ( ( rule__Question__Group__0 ) )
            // InternalDSL.g:200:3: ( rule__Question__Group__0 )
            {
             before(grammarAccess.getQuestionAccess().getGroup()); 
            // InternalDSL.g:201:3: ( rule__Question__Group__0 )
            // InternalDSL.g:201:4: rule__Question__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Question__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getQuestionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleQuestion"


    // $ANTLR start "entryRuleOptions"
    // InternalDSL.g:210:1: entryRuleOptions : ruleOptions EOF ;
    public final void entryRuleOptions() throws RecognitionException {
        try {
            // InternalDSL.g:211:1: ( ruleOptions EOF )
            // InternalDSL.g:212:1: ruleOptions EOF
            {
             before(grammarAccess.getOptionsRule()); 
            pushFollow(FOLLOW_1);
            ruleOptions();

            state._fsp--;

             after(grammarAccess.getOptionsRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleOptions"


    // $ANTLR start "ruleOptions"
    // InternalDSL.g:219:1: ruleOptions : ( ( rule__Options__Group__0 ) ) ;
    public final void ruleOptions() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:223:2: ( ( ( rule__Options__Group__0 ) ) )
            // InternalDSL.g:224:2: ( ( rule__Options__Group__0 ) )
            {
            // InternalDSL.g:224:2: ( ( rule__Options__Group__0 ) )
            // InternalDSL.g:225:3: ( rule__Options__Group__0 )
            {
             before(grammarAccess.getOptionsAccess().getGroup()); 
            // InternalDSL.g:226:3: ( rule__Options__Group__0 )
            // InternalDSL.g:226:4: rule__Options__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Options__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getOptionsAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleOptions"


    // $ANTLR start "entryRuleOption"
    // InternalDSL.g:235:1: entryRuleOption : ruleOption EOF ;
    public final void entryRuleOption() throws RecognitionException {
        try {
            // InternalDSL.g:236:1: ( ruleOption EOF )
            // InternalDSL.g:237:1: ruleOption EOF
            {
             before(grammarAccess.getOptionRule()); 
            pushFollow(FOLLOW_1);
            ruleOption();

            state._fsp--;

             after(grammarAccess.getOptionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleOption"


    // $ANTLR start "ruleOption"
    // InternalDSL.g:244:1: ruleOption : ( ( rule__Option__Group__0 ) ) ;
    public final void ruleOption() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:248:2: ( ( ( rule__Option__Group__0 ) ) )
            // InternalDSL.g:249:2: ( ( rule__Option__Group__0 ) )
            {
            // InternalDSL.g:249:2: ( ( rule__Option__Group__0 ) )
            // InternalDSL.g:250:3: ( rule__Option__Group__0 )
            {
             before(grammarAccess.getOptionAccess().getGroup()); 
            // InternalDSL.g:251:3: ( rule__Option__Group__0 )
            // InternalDSL.g:251:4: rule__Option__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Option__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getOptionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleOption"


    // $ANTLR start "entryRuleGoTo"
    // InternalDSL.g:260:1: entryRuleGoTo : ruleGoTo EOF ;
    public final void entryRuleGoTo() throws RecognitionException {
        try {
            // InternalDSL.g:261:1: ( ruleGoTo EOF )
            // InternalDSL.g:262:1: ruleGoTo EOF
            {
             before(grammarAccess.getGoToRule()); 
            pushFollow(FOLLOW_1);
            ruleGoTo();

            state._fsp--;

             after(grammarAccess.getGoToRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleGoTo"


    // $ANTLR start "ruleGoTo"
    // InternalDSL.g:269:1: ruleGoTo : ( ( rule__GoTo__Group__0 ) ) ;
    public final void ruleGoTo() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:273:2: ( ( ( rule__GoTo__Group__0 ) ) )
            // InternalDSL.g:274:2: ( ( rule__GoTo__Group__0 ) )
            {
            // InternalDSL.g:274:2: ( ( rule__GoTo__Group__0 ) )
            // InternalDSL.g:275:3: ( rule__GoTo__Group__0 )
            {
             before(grammarAccess.getGoToAccess().getGroup()); 
            // InternalDSL.g:276:3: ( rule__GoTo__Group__0 )
            // InternalDSL.g:276:4: rule__GoTo__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__GoTo__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getGoToAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleGoTo"


    // $ANTLR start "entryRuleNameWithUnderscore"
    // InternalDSL.g:285:1: entryRuleNameWithUnderscore : ruleNameWithUnderscore EOF ;
    public final void entryRuleNameWithUnderscore() throws RecognitionException {
        try {
            // InternalDSL.g:286:1: ( ruleNameWithUnderscore EOF )
            // InternalDSL.g:287:1: ruleNameWithUnderscore EOF
            {
             before(grammarAccess.getNameWithUnderscoreRule()); 
            pushFollow(FOLLOW_1);
            ruleNameWithUnderscore();

            state._fsp--;

             after(grammarAccess.getNameWithUnderscoreRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleNameWithUnderscore"


    // $ANTLR start "ruleNameWithUnderscore"
    // InternalDSL.g:294:1: ruleNameWithUnderscore : ( ( rule__NameWithUnderscore__Group__0 ) ) ;
    public final void ruleNameWithUnderscore() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:298:2: ( ( ( rule__NameWithUnderscore__Group__0 ) ) )
            // InternalDSL.g:299:2: ( ( rule__NameWithUnderscore__Group__0 ) )
            {
            // InternalDSL.g:299:2: ( ( rule__NameWithUnderscore__Group__0 ) )
            // InternalDSL.g:300:3: ( rule__NameWithUnderscore__Group__0 )
            {
             before(grammarAccess.getNameWithUnderscoreAccess().getGroup()); 
            // InternalDSL.g:301:3: ( rule__NameWithUnderscore__Group__0 )
            // InternalDSL.g:301:4: rule__NameWithUnderscore__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__NameWithUnderscore__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getNameWithUnderscoreAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleNameWithUnderscore"


    // $ANTLR start "rule__PartOfStory__Alternatives_6"
    // InternalDSL.g:309:1: rule__PartOfStory__Alternatives_6 : ( ( ( rule__PartOfStory__AllOptionsAssignment_6_0 )* ) | ( ( rule__PartOfStory__GotoAssignment_6_1 )? ) );
    public final void rule__PartOfStory__Alternatives_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:313:1: ( ( ( rule__PartOfStory__AllOptionsAssignment_6_0 )* ) | ( ( rule__PartOfStory__GotoAssignment_6_1 )? ) )
            int alt5=2;
            switch ( input.LA(1) ) {
            case 18:
                {
                alt5=1;
                }
                break;
            case 15:
                {
                alt5=1;
                }
                break;
            case 21:
                {
                alt5=2;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }

            switch (alt5) {
                case 1 :
                    // InternalDSL.g:314:2: ( ( rule__PartOfStory__AllOptionsAssignment_6_0 )* )
                    {
                    // InternalDSL.g:314:2: ( ( rule__PartOfStory__AllOptionsAssignment_6_0 )* )
                    // InternalDSL.g:315:3: ( rule__PartOfStory__AllOptionsAssignment_6_0 )*
                    {
                     before(grammarAccess.getPartOfStoryAccess().getAllOptionsAssignment_6_0()); 
                    // InternalDSL.g:316:3: ( rule__PartOfStory__AllOptionsAssignment_6_0 )*
                    loop3:
                    do {
                        int alt3=2;
                        int LA3_0 = input.LA(1);

                        if ( (LA3_0==18) ) {
                            alt3=1;
                        }


                        switch (alt3) {
                    	case 1 :
                    	    // InternalDSL.g:316:4: rule__PartOfStory__AllOptionsAssignment_6_0
                    	    {
                    	    pushFollow(FOLLOW_5);
                    	    rule__PartOfStory__AllOptionsAssignment_6_0();

                    	    state._fsp--;


                    	    }
                    	    break;

                    	default :
                    	    break loop3;
                        }
                    } while (true);

                     after(grammarAccess.getPartOfStoryAccess().getAllOptionsAssignment_6_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalDSL.g:320:2: ( ( rule__PartOfStory__GotoAssignment_6_1 )? )
                    {
                    // InternalDSL.g:320:2: ( ( rule__PartOfStory__GotoAssignment_6_1 )? )
                    // InternalDSL.g:321:3: ( rule__PartOfStory__GotoAssignment_6_1 )?
                    {
                     before(grammarAccess.getPartOfStoryAccess().getGotoAssignment_6_1()); 
                    // InternalDSL.g:322:3: ( rule__PartOfStory__GotoAssignment_6_1 )?
                    int alt4=2;
                    int LA4_0 = input.LA(1);

                    if ( (LA4_0==21) ) {
                        alt4=1;
                    }
                    switch (alt4) {
                        case 1 :
                            // InternalDSL.g:322:4: rule__PartOfStory__GotoAssignment_6_1
                            {
                            pushFollow(FOLLOW_2);
                            rule__PartOfStory__GotoAssignment_6_1();

                            state._fsp--;


                            }
                            break;

                    }

                     after(grammarAccess.getPartOfStoryAccess().getGotoAssignment_6_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PartOfStory__Alternatives_6"


    // $ANTLR start "rule__PartOfStory__Group__0"
    // InternalDSL.g:330:1: rule__PartOfStory__Group__0 : rule__PartOfStory__Group__0__Impl rule__PartOfStory__Group__1 ;
    public final void rule__PartOfStory__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:334:1: ( rule__PartOfStory__Group__0__Impl rule__PartOfStory__Group__1 )
            // InternalDSL.g:335:2: rule__PartOfStory__Group__0__Impl rule__PartOfStory__Group__1
            {
            pushFollow(FOLLOW_6);
            rule__PartOfStory__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__PartOfStory__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PartOfStory__Group__0"


    // $ANTLR start "rule__PartOfStory__Group__0__Impl"
    // InternalDSL.g:342:1: rule__PartOfStory__Group__0__Impl : ( 'partOfStory' ) ;
    public final void rule__PartOfStory__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:346:1: ( ( 'partOfStory' ) )
            // InternalDSL.g:347:1: ( 'partOfStory' )
            {
            // InternalDSL.g:347:1: ( 'partOfStory' )
            // InternalDSL.g:348:2: 'partOfStory'
            {
             before(grammarAccess.getPartOfStoryAccess().getPartOfStoryKeyword_0()); 
            match(input,13,FOLLOW_2); 
             after(grammarAccess.getPartOfStoryAccess().getPartOfStoryKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PartOfStory__Group__0__Impl"


    // $ANTLR start "rule__PartOfStory__Group__1"
    // InternalDSL.g:357:1: rule__PartOfStory__Group__1 : rule__PartOfStory__Group__1__Impl rule__PartOfStory__Group__2 ;
    public final void rule__PartOfStory__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:361:1: ( rule__PartOfStory__Group__1__Impl rule__PartOfStory__Group__2 )
            // InternalDSL.g:362:2: rule__PartOfStory__Group__1__Impl rule__PartOfStory__Group__2
            {
            pushFollow(FOLLOW_7);
            rule__PartOfStory__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__PartOfStory__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PartOfStory__Group__1"


    // $ANTLR start "rule__PartOfStory__Group__1__Impl"
    // InternalDSL.g:369:1: rule__PartOfStory__Group__1__Impl : ( ( rule__PartOfStory__NameAssignment_1 ) ) ;
    public final void rule__PartOfStory__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:373:1: ( ( ( rule__PartOfStory__NameAssignment_1 ) ) )
            // InternalDSL.g:374:1: ( ( rule__PartOfStory__NameAssignment_1 ) )
            {
            // InternalDSL.g:374:1: ( ( rule__PartOfStory__NameAssignment_1 ) )
            // InternalDSL.g:375:2: ( rule__PartOfStory__NameAssignment_1 )
            {
             before(grammarAccess.getPartOfStoryAccess().getNameAssignment_1()); 
            // InternalDSL.g:376:2: ( rule__PartOfStory__NameAssignment_1 )
            // InternalDSL.g:376:3: rule__PartOfStory__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__PartOfStory__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getPartOfStoryAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PartOfStory__Group__1__Impl"


    // $ANTLR start "rule__PartOfStory__Group__2"
    // InternalDSL.g:384:1: rule__PartOfStory__Group__2 : rule__PartOfStory__Group__2__Impl rule__PartOfStory__Group__3 ;
    public final void rule__PartOfStory__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:388:1: ( rule__PartOfStory__Group__2__Impl rule__PartOfStory__Group__3 )
            // InternalDSL.g:389:2: rule__PartOfStory__Group__2__Impl rule__PartOfStory__Group__3
            {
            pushFollow(FOLLOW_8);
            rule__PartOfStory__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__PartOfStory__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PartOfStory__Group__2"


    // $ANTLR start "rule__PartOfStory__Group__2__Impl"
    // InternalDSL.g:396:1: rule__PartOfStory__Group__2__Impl : ( '{' ) ;
    public final void rule__PartOfStory__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:400:1: ( ( '{' ) )
            // InternalDSL.g:401:1: ( '{' )
            {
            // InternalDSL.g:401:1: ( '{' )
            // InternalDSL.g:402:2: '{'
            {
             before(grammarAccess.getPartOfStoryAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getPartOfStoryAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PartOfStory__Group__2__Impl"


    // $ANTLR start "rule__PartOfStory__Group__3"
    // InternalDSL.g:411:1: rule__PartOfStory__Group__3 : rule__PartOfStory__Group__3__Impl rule__PartOfStory__Group__4 ;
    public final void rule__PartOfStory__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:415:1: ( rule__PartOfStory__Group__3__Impl rule__PartOfStory__Group__4 )
            // InternalDSL.g:416:2: rule__PartOfStory__Group__3__Impl rule__PartOfStory__Group__4
            {
            pushFollow(FOLLOW_8);
            rule__PartOfStory__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__PartOfStory__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PartOfStory__Group__3"


    // $ANTLR start "rule__PartOfStory__Group__3__Impl"
    // InternalDSL.g:423:1: rule__PartOfStory__Group__3__Impl : ( ( rule__PartOfStory__StartAssignment_3 )? ) ;
    public final void rule__PartOfStory__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:427:1: ( ( ( rule__PartOfStory__StartAssignment_3 )? ) )
            // InternalDSL.g:428:1: ( ( rule__PartOfStory__StartAssignment_3 )? )
            {
            // InternalDSL.g:428:1: ( ( rule__PartOfStory__StartAssignment_3 )? )
            // InternalDSL.g:429:2: ( rule__PartOfStory__StartAssignment_3 )?
            {
             before(grammarAccess.getPartOfStoryAccess().getStartAssignment_3()); 
            // InternalDSL.g:430:2: ( rule__PartOfStory__StartAssignment_3 )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==RULE_START) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // InternalDSL.g:430:3: rule__PartOfStory__StartAssignment_3
                    {
                    pushFollow(FOLLOW_2);
                    rule__PartOfStory__StartAssignment_3();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getPartOfStoryAccess().getStartAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PartOfStory__Group__3__Impl"


    // $ANTLR start "rule__PartOfStory__Group__4"
    // InternalDSL.g:438:1: rule__PartOfStory__Group__4 : rule__PartOfStory__Group__4__Impl rule__PartOfStory__Group__5 ;
    public final void rule__PartOfStory__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:442:1: ( rule__PartOfStory__Group__4__Impl rule__PartOfStory__Group__5 )
            // InternalDSL.g:443:2: rule__PartOfStory__Group__4__Impl rule__PartOfStory__Group__5
            {
            pushFollow(FOLLOW_9);
            rule__PartOfStory__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__PartOfStory__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PartOfStory__Group__4"


    // $ANTLR start "rule__PartOfStory__Group__4__Impl"
    // InternalDSL.g:450:1: rule__PartOfStory__Group__4__Impl : ( ( ( rule__PartOfStory__GameTextsAssignment_4 ) ) ( ( rule__PartOfStory__GameTextsAssignment_4 )* ) ) ;
    public final void rule__PartOfStory__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:454:1: ( ( ( ( rule__PartOfStory__GameTextsAssignment_4 ) ) ( ( rule__PartOfStory__GameTextsAssignment_4 )* ) ) )
            // InternalDSL.g:455:1: ( ( ( rule__PartOfStory__GameTextsAssignment_4 ) ) ( ( rule__PartOfStory__GameTextsAssignment_4 )* ) )
            {
            // InternalDSL.g:455:1: ( ( ( rule__PartOfStory__GameTextsAssignment_4 ) ) ( ( rule__PartOfStory__GameTextsAssignment_4 )* ) )
            // InternalDSL.g:456:2: ( ( rule__PartOfStory__GameTextsAssignment_4 ) ) ( ( rule__PartOfStory__GameTextsAssignment_4 )* )
            {
            // InternalDSL.g:456:2: ( ( rule__PartOfStory__GameTextsAssignment_4 ) )
            // InternalDSL.g:457:3: ( rule__PartOfStory__GameTextsAssignment_4 )
            {
             before(grammarAccess.getPartOfStoryAccess().getGameTextsAssignment_4()); 
            // InternalDSL.g:458:3: ( rule__PartOfStory__GameTextsAssignment_4 )
            // InternalDSL.g:458:4: rule__PartOfStory__GameTextsAssignment_4
            {
            pushFollow(FOLLOW_10);
            rule__PartOfStory__GameTextsAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getPartOfStoryAccess().getGameTextsAssignment_4()); 

            }

            // InternalDSL.g:461:2: ( ( rule__PartOfStory__GameTextsAssignment_4 )* )
            // InternalDSL.g:462:3: ( rule__PartOfStory__GameTextsAssignment_4 )*
            {
             before(grammarAccess.getPartOfStoryAccess().getGameTextsAssignment_4()); 
            // InternalDSL.g:463:3: ( rule__PartOfStory__GameTextsAssignment_4 )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==16) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // InternalDSL.g:463:4: rule__PartOfStory__GameTextsAssignment_4
            	    {
            	    pushFollow(FOLLOW_10);
            	    rule__PartOfStory__GameTextsAssignment_4();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);

             after(grammarAccess.getPartOfStoryAccess().getGameTextsAssignment_4()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PartOfStory__Group__4__Impl"


    // $ANTLR start "rule__PartOfStory__Group__5"
    // InternalDSL.g:472:1: rule__PartOfStory__Group__5 : rule__PartOfStory__Group__5__Impl rule__PartOfStory__Group__6 ;
    public final void rule__PartOfStory__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:476:1: ( rule__PartOfStory__Group__5__Impl rule__PartOfStory__Group__6 )
            // InternalDSL.g:477:2: rule__PartOfStory__Group__5__Impl rule__PartOfStory__Group__6
            {
            pushFollow(FOLLOW_9);
            rule__PartOfStory__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__PartOfStory__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PartOfStory__Group__5"


    // $ANTLR start "rule__PartOfStory__Group__5__Impl"
    // InternalDSL.g:484:1: rule__PartOfStory__Group__5__Impl : ( ( rule__PartOfStory__QuestionAssignment_5 )? ) ;
    public final void rule__PartOfStory__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:488:1: ( ( ( rule__PartOfStory__QuestionAssignment_5 )? ) )
            // InternalDSL.g:489:1: ( ( rule__PartOfStory__QuestionAssignment_5 )? )
            {
            // InternalDSL.g:489:1: ( ( rule__PartOfStory__QuestionAssignment_5 )? )
            // InternalDSL.g:490:2: ( rule__PartOfStory__QuestionAssignment_5 )?
            {
             before(grammarAccess.getPartOfStoryAccess().getQuestionAssignment_5()); 
            // InternalDSL.g:491:2: ( rule__PartOfStory__QuestionAssignment_5 )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==17) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalDSL.g:491:3: rule__PartOfStory__QuestionAssignment_5
                    {
                    pushFollow(FOLLOW_2);
                    rule__PartOfStory__QuestionAssignment_5();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getPartOfStoryAccess().getQuestionAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PartOfStory__Group__5__Impl"


    // $ANTLR start "rule__PartOfStory__Group__6"
    // InternalDSL.g:499:1: rule__PartOfStory__Group__6 : rule__PartOfStory__Group__6__Impl rule__PartOfStory__Group__7 ;
    public final void rule__PartOfStory__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:503:1: ( rule__PartOfStory__Group__6__Impl rule__PartOfStory__Group__7 )
            // InternalDSL.g:504:2: rule__PartOfStory__Group__6__Impl rule__PartOfStory__Group__7
            {
            pushFollow(FOLLOW_11);
            rule__PartOfStory__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__PartOfStory__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PartOfStory__Group__6"


    // $ANTLR start "rule__PartOfStory__Group__6__Impl"
    // InternalDSL.g:511:1: rule__PartOfStory__Group__6__Impl : ( ( rule__PartOfStory__Alternatives_6 ) ) ;
    public final void rule__PartOfStory__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:515:1: ( ( ( rule__PartOfStory__Alternatives_6 ) ) )
            // InternalDSL.g:516:1: ( ( rule__PartOfStory__Alternatives_6 ) )
            {
            // InternalDSL.g:516:1: ( ( rule__PartOfStory__Alternatives_6 ) )
            // InternalDSL.g:517:2: ( rule__PartOfStory__Alternatives_6 )
            {
             before(grammarAccess.getPartOfStoryAccess().getAlternatives_6()); 
            // InternalDSL.g:518:2: ( rule__PartOfStory__Alternatives_6 )
            // InternalDSL.g:518:3: rule__PartOfStory__Alternatives_6
            {
            pushFollow(FOLLOW_2);
            rule__PartOfStory__Alternatives_6();

            state._fsp--;


            }

             after(grammarAccess.getPartOfStoryAccess().getAlternatives_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PartOfStory__Group__6__Impl"


    // $ANTLR start "rule__PartOfStory__Group__7"
    // InternalDSL.g:526:1: rule__PartOfStory__Group__7 : rule__PartOfStory__Group__7__Impl ;
    public final void rule__PartOfStory__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:530:1: ( rule__PartOfStory__Group__7__Impl )
            // InternalDSL.g:531:2: rule__PartOfStory__Group__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__PartOfStory__Group__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PartOfStory__Group__7"


    // $ANTLR start "rule__PartOfStory__Group__7__Impl"
    // InternalDSL.g:537:1: rule__PartOfStory__Group__7__Impl : ( '}' ) ;
    public final void rule__PartOfStory__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:541:1: ( ( '}' ) )
            // InternalDSL.g:542:1: ( '}' )
            {
            // InternalDSL.g:542:1: ( '}' )
            // InternalDSL.g:543:2: '}'
            {
             before(grammarAccess.getPartOfStoryAccess().getRightCurlyBracketKeyword_7()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getPartOfStoryAccess().getRightCurlyBracketKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PartOfStory__Group__7__Impl"


    // $ANTLR start "rule__GameText__Group__0"
    // InternalDSL.g:553:1: rule__GameText__Group__0 : rule__GameText__Group__0__Impl rule__GameText__Group__1 ;
    public final void rule__GameText__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:557:1: ( rule__GameText__Group__0__Impl rule__GameText__Group__1 )
            // InternalDSL.g:558:2: rule__GameText__Group__0__Impl rule__GameText__Group__1
            {
            pushFollow(FOLLOW_12);
            rule__GameText__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameText__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameText__Group__0"


    // $ANTLR start "rule__GameText__Group__0__Impl"
    // InternalDSL.g:565:1: rule__GameText__Group__0__Impl : ( '<t>' ) ;
    public final void rule__GameText__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:569:1: ( ( '<t>' ) )
            // InternalDSL.g:570:1: ( '<t>' )
            {
            // InternalDSL.g:570:1: ( '<t>' )
            // InternalDSL.g:571:2: '<t>'
            {
             before(grammarAccess.getGameTextAccess().getTKeyword_0()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getGameTextAccess().getTKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameText__Group__0__Impl"


    // $ANTLR start "rule__GameText__Group__1"
    // InternalDSL.g:580:1: rule__GameText__Group__1 : rule__GameText__Group__1__Impl rule__GameText__Group__2 ;
    public final void rule__GameText__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:584:1: ( rule__GameText__Group__1__Impl rule__GameText__Group__2 )
            // InternalDSL.g:585:2: rule__GameText__Group__1__Impl rule__GameText__Group__2
            {
            pushFollow(FOLLOW_13);
            rule__GameText__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameText__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameText__Group__1"


    // $ANTLR start "rule__GameText__Group__1__Impl"
    // InternalDSL.g:592:1: rule__GameText__Group__1__Impl : ( ( rule__GameText__ContentAssignment_1 ) ) ;
    public final void rule__GameText__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:596:1: ( ( ( rule__GameText__ContentAssignment_1 ) ) )
            // InternalDSL.g:597:1: ( ( rule__GameText__ContentAssignment_1 ) )
            {
            // InternalDSL.g:597:1: ( ( rule__GameText__ContentAssignment_1 ) )
            // InternalDSL.g:598:2: ( rule__GameText__ContentAssignment_1 )
            {
             before(grammarAccess.getGameTextAccess().getContentAssignment_1()); 
            // InternalDSL.g:599:2: ( rule__GameText__ContentAssignment_1 )
            // InternalDSL.g:599:3: rule__GameText__ContentAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__GameText__ContentAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getGameTextAccess().getContentAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameText__Group__1__Impl"


    // $ANTLR start "rule__GameText__Group__2"
    // InternalDSL.g:607:1: rule__GameText__Group__2 : rule__GameText__Group__2__Impl ;
    public final void rule__GameText__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:611:1: ( rule__GameText__Group__2__Impl )
            // InternalDSL.g:612:2: rule__GameText__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__GameText__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameText__Group__2"


    // $ANTLR start "rule__GameText__Group__2__Impl"
    // InternalDSL.g:618:1: rule__GameText__Group__2__Impl : ( '<t>' ) ;
    public final void rule__GameText__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:622:1: ( ( '<t>' ) )
            // InternalDSL.g:623:1: ( '<t>' )
            {
            // InternalDSL.g:623:1: ( '<t>' )
            // InternalDSL.g:624:2: '<t>'
            {
             before(grammarAccess.getGameTextAccess().getTKeyword_2()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getGameTextAccess().getTKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameText__Group__2__Impl"


    // $ANTLR start "rule__Question__Group__0"
    // InternalDSL.g:634:1: rule__Question__Group__0 : rule__Question__Group__0__Impl rule__Question__Group__1 ;
    public final void rule__Question__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:638:1: ( rule__Question__Group__0__Impl rule__Question__Group__1 )
            // InternalDSL.g:639:2: rule__Question__Group__0__Impl rule__Question__Group__1
            {
            pushFollow(FOLLOW_12);
            rule__Question__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Question__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Question__Group__0"


    // $ANTLR start "rule__Question__Group__0__Impl"
    // InternalDSL.g:646:1: rule__Question__Group__0__Impl : ( '<?>' ) ;
    public final void rule__Question__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:650:1: ( ( '<?>' ) )
            // InternalDSL.g:651:1: ( '<?>' )
            {
            // InternalDSL.g:651:1: ( '<?>' )
            // InternalDSL.g:652:2: '<?>'
            {
             before(grammarAccess.getQuestionAccess().getLessThanSignQuestionMarkGreaterThanSignKeyword_0()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getQuestionAccess().getLessThanSignQuestionMarkGreaterThanSignKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Question__Group__0__Impl"


    // $ANTLR start "rule__Question__Group__1"
    // InternalDSL.g:661:1: rule__Question__Group__1 : rule__Question__Group__1__Impl rule__Question__Group__2 ;
    public final void rule__Question__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:665:1: ( rule__Question__Group__1__Impl rule__Question__Group__2 )
            // InternalDSL.g:666:2: rule__Question__Group__1__Impl rule__Question__Group__2
            {
            pushFollow(FOLLOW_14);
            rule__Question__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Question__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Question__Group__1"


    // $ANTLR start "rule__Question__Group__1__Impl"
    // InternalDSL.g:673:1: rule__Question__Group__1__Impl : ( ( rule__Question__ContentAssignment_1 ) ) ;
    public final void rule__Question__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:677:1: ( ( ( rule__Question__ContentAssignment_1 ) ) )
            // InternalDSL.g:678:1: ( ( rule__Question__ContentAssignment_1 ) )
            {
            // InternalDSL.g:678:1: ( ( rule__Question__ContentAssignment_1 ) )
            // InternalDSL.g:679:2: ( rule__Question__ContentAssignment_1 )
            {
             before(grammarAccess.getQuestionAccess().getContentAssignment_1()); 
            // InternalDSL.g:680:2: ( rule__Question__ContentAssignment_1 )
            // InternalDSL.g:680:3: rule__Question__ContentAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Question__ContentAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getQuestionAccess().getContentAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Question__Group__1__Impl"


    // $ANTLR start "rule__Question__Group__2"
    // InternalDSL.g:688:1: rule__Question__Group__2 : rule__Question__Group__2__Impl ;
    public final void rule__Question__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:692:1: ( rule__Question__Group__2__Impl )
            // InternalDSL.g:693:2: rule__Question__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Question__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Question__Group__2"


    // $ANTLR start "rule__Question__Group__2__Impl"
    // InternalDSL.g:699:1: rule__Question__Group__2__Impl : ( '<?>' ) ;
    public final void rule__Question__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:703:1: ( ( '<?>' ) )
            // InternalDSL.g:704:1: ( '<?>' )
            {
            // InternalDSL.g:704:1: ( '<?>' )
            // InternalDSL.g:705:2: '<?>'
            {
             before(grammarAccess.getQuestionAccess().getLessThanSignQuestionMarkGreaterThanSignKeyword_2()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getQuestionAccess().getLessThanSignQuestionMarkGreaterThanSignKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Question__Group__2__Impl"


    // $ANTLR start "rule__Options__Group__0"
    // InternalDSL.g:715:1: rule__Options__Group__0 : rule__Options__Group__0__Impl rule__Options__Group__1 ;
    public final void rule__Options__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:719:1: ( rule__Options__Group__0__Impl rule__Options__Group__1 )
            // InternalDSL.g:720:2: rule__Options__Group__0__Impl rule__Options__Group__1
            {
            pushFollow(FOLLOW_15);
            rule__Options__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Options__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Options__Group__0"


    // $ANTLR start "rule__Options__Group__0__Impl"
    // InternalDSL.g:727:1: rule__Options__Group__0__Impl : ( '<!>' ) ;
    public final void rule__Options__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:731:1: ( ( '<!>' ) )
            // InternalDSL.g:732:1: ( '<!>' )
            {
            // InternalDSL.g:732:1: ( '<!>' )
            // InternalDSL.g:733:2: '<!>'
            {
             before(grammarAccess.getOptionsAccess().getLessThanSignExclamationMarkGreaterThanSignKeyword_0()); 
            match(input,18,FOLLOW_2); 
             after(grammarAccess.getOptionsAccess().getLessThanSignExclamationMarkGreaterThanSignKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Options__Group__0__Impl"


    // $ANTLR start "rule__Options__Group__1"
    // InternalDSL.g:742:1: rule__Options__Group__1 : rule__Options__Group__1__Impl rule__Options__Group__2 ;
    public final void rule__Options__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:746:1: ( rule__Options__Group__1__Impl rule__Options__Group__2 )
            // InternalDSL.g:747:2: rule__Options__Group__1__Impl rule__Options__Group__2
            {
            pushFollow(FOLLOW_16);
            rule__Options__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Options__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Options__Group__1"


    // $ANTLR start "rule__Options__Group__1__Impl"
    // InternalDSL.g:754:1: rule__Options__Group__1__Impl : ( ( rule__Options__OptionsAssignment_1 ) ) ;
    public final void rule__Options__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:758:1: ( ( ( rule__Options__OptionsAssignment_1 ) ) )
            // InternalDSL.g:759:1: ( ( rule__Options__OptionsAssignment_1 ) )
            {
            // InternalDSL.g:759:1: ( ( rule__Options__OptionsAssignment_1 ) )
            // InternalDSL.g:760:2: ( rule__Options__OptionsAssignment_1 )
            {
             before(grammarAccess.getOptionsAccess().getOptionsAssignment_1()); 
            // InternalDSL.g:761:2: ( rule__Options__OptionsAssignment_1 )
            // InternalDSL.g:761:3: rule__Options__OptionsAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Options__OptionsAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getOptionsAccess().getOptionsAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Options__Group__1__Impl"


    // $ANTLR start "rule__Options__Group__2"
    // InternalDSL.g:769:1: rule__Options__Group__2 : rule__Options__Group__2__Impl rule__Options__Group__3 ;
    public final void rule__Options__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:773:1: ( rule__Options__Group__2__Impl rule__Options__Group__3 )
            // InternalDSL.g:774:2: rule__Options__Group__2__Impl rule__Options__Group__3
            {
            pushFollow(FOLLOW_16);
            rule__Options__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Options__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Options__Group__2"


    // $ANTLR start "rule__Options__Group__2__Impl"
    // InternalDSL.g:781:1: rule__Options__Group__2__Impl : ( ( rule__Options__Group_2__0 )* ) ;
    public final void rule__Options__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:785:1: ( ( ( rule__Options__Group_2__0 )* ) )
            // InternalDSL.g:786:1: ( ( rule__Options__Group_2__0 )* )
            {
            // InternalDSL.g:786:1: ( ( rule__Options__Group_2__0 )* )
            // InternalDSL.g:787:2: ( rule__Options__Group_2__0 )*
            {
             before(grammarAccess.getOptionsAccess().getGroup_2()); 
            // InternalDSL.g:788:2: ( rule__Options__Group_2__0 )*
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( (LA9_0==19) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // InternalDSL.g:788:3: rule__Options__Group_2__0
            	    {
            	    pushFollow(FOLLOW_17);
            	    rule__Options__Group_2__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);

             after(grammarAccess.getOptionsAccess().getGroup_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Options__Group__2__Impl"


    // $ANTLR start "rule__Options__Group__3"
    // InternalDSL.g:796:1: rule__Options__Group__3 : rule__Options__Group__3__Impl ;
    public final void rule__Options__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:800:1: ( rule__Options__Group__3__Impl )
            // InternalDSL.g:801:2: rule__Options__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Options__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Options__Group__3"


    // $ANTLR start "rule__Options__Group__3__Impl"
    // InternalDSL.g:807:1: rule__Options__Group__3__Impl : ( '<!>' ) ;
    public final void rule__Options__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:811:1: ( ( '<!>' ) )
            // InternalDSL.g:812:1: ( '<!>' )
            {
            // InternalDSL.g:812:1: ( '<!>' )
            // InternalDSL.g:813:2: '<!>'
            {
             before(grammarAccess.getOptionsAccess().getLessThanSignExclamationMarkGreaterThanSignKeyword_3()); 
            match(input,18,FOLLOW_2); 
             after(grammarAccess.getOptionsAccess().getLessThanSignExclamationMarkGreaterThanSignKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Options__Group__3__Impl"


    // $ANTLR start "rule__Options__Group_2__0"
    // InternalDSL.g:823:1: rule__Options__Group_2__0 : rule__Options__Group_2__0__Impl rule__Options__Group_2__1 ;
    public final void rule__Options__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:827:1: ( rule__Options__Group_2__0__Impl rule__Options__Group_2__1 )
            // InternalDSL.g:828:2: rule__Options__Group_2__0__Impl rule__Options__Group_2__1
            {
            pushFollow(FOLLOW_15);
            rule__Options__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Options__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Options__Group_2__0"


    // $ANTLR start "rule__Options__Group_2__0__Impl"
    // InternalDSL.g:835:1: rule__Options__Group_2__0__Impl : ( ',' ) ;
    public final void rule__Options__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:839:1: ( ( ',' ) )
            // InternalDSL.g:840:1: ( ',' )
            {
            // InternalDSL.g:840:1: ( ',' )
            // InternalDSL.g:841:2: ','
            {
             before(grammarAccess.getOptionsAccess().getCommaKeyword_2_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getOptionsAccess().getCommaKeyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Options__Group_2__0__Impl"


    // $ANTLR start "rule__Options__Group_2__1"
    // InternalDSL.g:850:1: rule__Options__Group_2__1 : rule__Options__Group_2__1__Impl ;
    public final void rule__Options__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:854:1: ( rule__Options__Group_2__1__Impl )
            // InternalDSL.g:855:2: rule__Options__Group_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Options__Group_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Options__Group_2__1"


    // $ANTLR start "rule__Options__Group_2__1__Impl"
    // InternalDSL.g:861:1: rule__Options__Group_2__1__Impl : ( ( rule__Options__OptionsAssignment_2_1 ) ) ;
    public final void rule__Options__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:865:1: ( ( ( rule__Options__OptionsAssignment_2_1 ) ) )
            // InternalDSL.g:866:1: ( ( rule__Options__OptionsAssignment_2_1 ) )
            {
            // InternalDSL.g:866:1: ( ( rule__Options__OptionsAssignment_2_1 ) )
            // InternalDSL.g:867:2: ( rule__Options__OptionsAssignment_2_1 )
            {
             before(grammarAccess.getOptionsAccess().getOptionsAssignment_2_1()); 
            // InternalDSL.g:868:2: ( rule__Options__OptionsAssignment_2_1 )
            // InternalDSL.g:868:3: rule__Options__OptionsAssignment_2_1
            {
            pushFollow(FOLLOW_2);
            rule__Options__OptionsAssignment_2_1();

            state._fsp--;


            }

             after(grammarAccess.getOptionsAccess().getOptionsAssignment_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Options__Group_2__1__Impl"


    // $ANTLR start "rule__Option__Group__0"
    // InternalDSL.g:877:1: rule__Option__Group__0 : rule__Option__Group__0__Impl rule__Option__Group__1 ;
    public final void rule__Option__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:881:1: ( rule__Option__Group__0__Impl rule__Option__Group__1 )
            // InternalDSL.g:882:2: rule__Option__Group__0__Impl rule__Option__Group__1
            {
            pushFollow(FOLLOW_18);
            rule__Option__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Option__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Option__Group__0"


    // $ANTLR start "rule__Option__Group__0__Impl"
    // InternalDSL.g:889:1: rule__Option__Group__0__Impl : ( ( rule__Option__NameAssignment_0 ) ) ;
    public final void rule__Option__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:893:1: ( ( ( rule__Option__NameAssignment_0 ) ) )
            // InternalDSL.g:894:1: ( ( rule__Option__NameAssignment_0 ) )
            {
            // InternalDSL.g:894:1: ( ( rule__Option__NameAssignment_0 ) )
            // InternalDSL.g:895:2: ( rule__Option__NameAssignment_0 )
            {
             before(grammarAccess.getOptionAccess().getNameAssignment_0()); 
            // InternalDSL.g:896:2: ( rule__Option__NameAssignment_0 )
            // InternalDSL.g:896:3: rule__Option__NameAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__Option__NameAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getOptionAccess().getNameAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Option__Group__0__Impl"


    // $ANTLR start "rule__Option__Group__1"
    // InternalDSL.g:904:1: rule__Option__Group__1 : rule__Option__Group__1__Impl rule__Option__Group__2 ;
    public final void rule__Option__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:908:1: ( rule__Option__Group__1__Impl rule__Option__Group__2 )
            // InternalDSL.g:909:2: rule__Option__Group__1__Impl rule__Option__Group__2
            {
            pushFollow(FOLLOW_12);
            rule__Option__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Option__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Option__Group__1"


    // $ANTLR start "rule__Option__Group__1__Impl"
    // InternalDSL.g:916:1: rule__Option__Group__1__Impl : ( ':' ) ;
    public final void rule__Option__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:920:1: ( ( ':' ) )
            // InternalDSL.g:921:1: ( ':' )
            {
            // InternalDSL.g:921:1: ( ':' )
            // InternalDSL.g:922:2: ':'
            {
             before(grammarAccess.getOptionAccess().getColonKeyword_1()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getOptionAccess().getColonKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Option__Group__1__Impl"


    // $ANTLR start "rule__Option__Group__2"
    // InternalDSL.g:931:1: rule__Option__Group__2 : rule__Option__Group__2__Impl rule__Option__Group__3 ;
    public final void rule__Option__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:935:1: ( rule__Option__Group__2__Impl rule__Option__Group__3 )
            // InternalDSL.g:936:2: rule__Option__Group__2__Impl rule__Option__Group__3
            {
            pushFollow(FOLLOW_19);
            rule__Option__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Option__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Option__Group__2"


    // $ANTLR start "rule__Option__Group__2__Impl"
    // InternalDSL.g:943:1: rule__Option__Group__2__Impl : ( ( rule__Option__ContentAssignment_2 ) ) ;
    public final void rule__Option__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:947:1: ( ( ( rule__Option__ContentAssignment_2 ) ) )
            // InternalDSL.g:948:1: ( ( rule__Option__ContentAssignment_2 ) )
            {
            // InternalDSL.g:948:1: ( ( rule__Option__ContentAssignment_2 ) )
            // InternalDSL.g:949:2: ( rule__Option__ContentAssignment_2 )
            {
             before(grammarAccess.getOptionAccess().getContentAssignment_2()); 
            // InternalDSL.g:950:2: ( rule__Option__ContentAssignment_2 )
            // InternalDSL.g:950:3: rule__Option__ContentAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Option__ContentAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getOptionAccess().getContentAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Option__Group__2__Impl"


    // $ANTLR start "rule__Option__Group__3"
    // InternalDSL.g:958:1: rule__Option__Group__3 : rule__Option__Group__3__Impl ;
    public final void rule__Option__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:962:1: ( rule__Option__Group__3__Impl )
            // InternalDSL.g:963:2: rule__Option__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Option__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Option__Group__3"


    // $ANTLR start "rule__Option__Group__3__Impl"
    // InternalDSL.g:969:1: rule__Option__Group__3__Impl : ( ( rule__Option__GotoAssignment_3 ) ) ;
    public final void rule__Option__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:973:1: ( ( ( rule__Option__GotoAssignment_3 ) ) )
            // InternalDSL.g:974:1: ( ( rule__Option__GotoAssignment_3 ) )
            {
            // InternalDSL.g:974:1: ( ( rule__Option__GotoAssignment_3 ) )
            // InternalDSL.g:975:2: ( rule__Option__GotoAssignment_3 )
            {
             before(grammarAccess.getOptionAccess().getGotoAssignment_3()); 
            // InternalDSL.g:976:2: ( rule__Option__GotoAssignment_3 )
            // InternalDSL.g:976:3: rule__Option__GotoAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Option__GotoAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getOptionAccess().getGotoAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Option__Group__3__Impl"


    // $ANTLR start "rule__GoTo__Group__0"
    // InternalDSL.g:985:1: rule__GoTo__Group__0 : rule__GoTo__Group__0__Impl rule__GoTo__Group__1 ;
    public final void rule__GoTo__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:989:1: ( rule__GoTo__Group__0__Impl rule__GoTo__Group__1 )
            // InternalDSL.g:990:2: rule__GoTo__Group__0__Impl rule__GoTo__Group__1
            {
            pushFollow(FOLLOW_6);
            rule__GoTo__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GoTo__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoTo__Group__0"


    // $ANTLR start "rule__GoTo__Group__0__Impl"
    // InternalDSL.g:997:1: rule__GoTo__Group__0__Impl : ( '---->' ) ;
    public final void rule__GoTo__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1001:1: ( ( '---->' ) )
            // InternalDSL.g:1002:1: ( '---->' )
            {
            // InternalDSL.g:1002:1: ( '---->' )
            // InternalDSL.g:1003:2: '---->'
            {
             before(grammarAccess.getGoToAccess().getHyphenMinusHyphenMinusHyphenMinusHyphenMinusGreaterThanSignKeyword_0()); 
            match(input,21,FOLLOW_2); 
             after(grammarAccess.getGoToAccess().getHyphenMinusHyphenMinusHyphenMinusHyphenMinusGreaterThanSignKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoTo__Group__0__Impl"


    // $ANTLR start "rule__GoTo__Group__1"
    // InternalDSL.g:1012:1: rule__GoTo__Group__1 : rule__GoTo__Group__1__Impl ;
    public final void rule__GoTo__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1016:1: ( rule__GoTo__Group__1__Impl )
            // InternalDSL.g:1017:2: rule__GoTo__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__GoTo__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoTo__Group__1"


    // $ANTLR start "rule__GoTo__Group__1__Impl"
    // InternalDSL.g:1023:1: rule__GoTo__Group__1__Impl : ( ( rule__GoTo__NextPartAssignment_1 ) ) ;
    public final void rule__GoTo__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1027:1: ( ( ( rule__GoTo__NextPartAssignment_1 ) ) )
            // InternalDSL.g:1028:1: ( ( rule__GoTo__NextPartAssignment_1 ) )
            {
            // InternalDSL.g:1028:1: ( ( rule__GoTo__NextPartAssignment_1 ) )
            // InternalDSL.g:1029:2: ( rule__GoTo__NextPartAssignment_1 )
            {
             before(grammarAccess.getGoToAccess().getNextPartAssignment_1()); 
            // InternalDSL.g:1030:2: ( rule__GoTo__NextPartAssignment_1 )
            // InternalDSL.g:1030:3: rule__GoTo__NextPartAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__GoTo__NextPartAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getGoToAccess().getNextPartAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoTo__Group__1__Impl"


    // $ANTLR start "rule__NameWithUnderscore__Group__0"
    // InternalDSL.g:1039:1: rule__NameWithUnderscore__Group__0 : rule__NameWithUnderscore__Group__0__Impl rule__NameWithUnderscore__Group__1 ;
    public final void rule__NameWithUnderscore__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1043:1: ( rule__NameWithUnderscore__Group__0__Impl rule__NameWithUnderscore__Group__1 )
            // InternalDSL.g:1044:2: rule__NameWithUnderscore__Group__0__Impl rule__NameWithUnderscore__Group__1
            {
            pushFollow(FOLLOW_20);
            rule__NameWithUnderscore__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__NameWithUnderscore__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NameWithUnderscore__Group__0"


    // $ANTLR start "rule__NameWithUnderscore__Group__0__Impl"
    // InternalDSL.g:1051:1: rule__NameWithUnderscore__Group__0__Impl : ( RULE_ID ) ;
    public final void rule__NameWithUnderscore__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1055:1: ( ( RULE_ID ) )
            // InternalDSL.g:1056:1: ( RULE_ID )
            {
            // InternalDSL.g:1056:1: ( RULE_ID )
            // InternalDSL.g:1057:2: RULE_ID
            {
             before(grammarAccess.getNameWithUnderscoreAccess().getIDTerminalRuleCall_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getNameWithUnderscoreAccess().getIDTerminalRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NameWithUnderscore__Group__0__Impl"


    // $ANTLR start "rule__NameWithUnderscore__Group__1"
    // InternalDSL.g:1066:1: rule__NameWithUnderscore__Group__1 : rule__NameWithUnderscore__Group__1__Impl ;
    public final void rule__NameWithUnderscore__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1070:1: ( rule__NameWithUnderscore__Group__1__Impl )
            // InternalDSL.g:1071:2: rule__NameWithUnderscore__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__NameWithUnderscore__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NameWithUnderscore__Group__1"


    // $ANTLR start "rule__NameWithUnderscore__Group__1__Impl"
    // InternalDSL.g:1077:1: rule__NameWithUnderscore__Group__1__Impl : ( ( rule__NameWithUnderscore__Group_1__0 )* ) ;
    public final void rule__NameWithUnderscore__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1081:1: ( ( ( rule__NameWithUnderscore__Group_1__0 )* ) )
            // InternalDSL.g:1082:1: ( ( rule__NameWithUnderscore__Group_1__0 )* )
            {
            // InternalDSL.g:1082:1: ( ( rule__NameWithUnderscore__Group_1__0 )* )
            // InternalDSL.g:1083:2: ( rule__NameWithUnderscore__Group_1__0 )*
            {
             before(grammarAccess.getNameWithUnderscoreAccess().getGroup_1()); 
            // InternalDSL.g:1084:2: ( rule__NameWithUnderscore__Group_1__0 )*
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( (LA10_0==22) ) {
                    alt10=1;
                }


                switch (alt10) {
            	case 1 :
            	    // InternalDSL.g:1084:3: rule__NameWithUnderscore__Group_1__0
            	    {
            	    pushFollow(FOLLOW_21);
            	    rule__NameWithUnderscore__Group_1__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);

             after(grammarAccess.getNameWithUnderscoreAccess().getGroup_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NameWithUnderscore__Group__1__Impl"


    // $ANTLR start "rule__NameWithUnderscore__Group_1__0"
    // InternalDSL.g:1093:1: rule__NameWithUnderscore__Group_1__0 : rule__NameWithUnderscore__Group_1__0__Impl rule__NameWithUnderscore__Group_1__1 ;
    public final void rule__NameWithUnderscore__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1097:1: ( rule__NameWithUnderscore__Group_1__0__Impl rule__NameWithUnderscore__Group_1__1 )
            // InternalDSL.g:1098:2: rule__NameWithUnderscore__Group_1__0__Impl rule__NameWithUnderscore__Group_1__1
            {
            pushFollow(FOLLOW_6);
            rule__NameWithUnderscore__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__NameWithUnderscore__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NameWithUnderscore__Group_1__0"


    // $ANTLR start "rule__NameWithUnderscore__Group_1__0__Impl"
    // InternalDSL.g:1105:1: rule__NameWithUnderscore__Group_1__0__Impl : ( '_' ) ;
    public final void rule__NameWithUnderscore__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1109:1: ( ( '_' ) )
            // InternalDSL.g:1110:1: ( '_' )
            {
            // InternalDSL.g:1110:1: ( '_' )
            // InternalDSL.g:1111:2: '_'
            {
             before(grammarAccess.getNameWithUnderscoreAccess().get_Keyword_1_0()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getNameWithUnderscoreAccess().get_Keyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NameWithUnderscore__Group_1__0__Impl"


    // $ANTLR start "rule__NameWithUnderscore__Group_1__1"
    // InternalDSL.g:1120:1: rule__NameWithUnderscore__Group_1__1 : rule__NameWithUnderscore__Group_1__1__Impl ;
    public final void rule__NameWithUnderscore__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1124:1: ( rule__NameWithUnderscore__Group_1__1__Impl )
            // InternalDSL.g:1125:2: rule__NameWithUnderscore__Group_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__NameWithUnderscore__Group_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NameWithUnderscore__Group_1__1"


    // $ANTLR start "rule__NameWithUnderscore__Group_1__1__Impl"
    // InternalDSL.g:1131:1: rule__NameWithUnderscore__Group_1__1__Impl : ( RULE_ID ) ;
    public final void rule__NameWithUnderscore__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1135:1: ( ( RULE_ID ) )
            // InternalDSL.g:1136:1: ( RULE_ID )
            {
            // InternalDSL.g:1136:1: ( RULE_ID )
            // InternalDSL.g:1137:2: RULE_ID
            {
             before(grammarAccess.getNameWithUnderscoreAccess().getIDTerminalRuleCall_1_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getNameWithUnderscoreAccess().getIDTerminalRuleCall_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NameWithUnderscore__Group_1__1__Impl"


    // $ANTLR start "rule__Model__ElementsAssignment"
    // InternalDSL.g:1147:1: rule__Model__ElementsAssignment : ( ruleAbstractElement ) ;
    public final void rule__Model__ElementsAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1151:1: ( ( ruleAbstractElement ) )
            // InternalDSL.g:1152:2: ( ruleAbstractElement )
            {
            // InternalDSL.g:1152:2: ( ruleAbstractElement )
            // InternalDSL.g:1153:3: ruleAbstractElement
            {
             before(grammarAccess.getModelAccess().getElementsAbstractElementParserRuleCall_0()); 
            pushFollow(FOLLOW_2);
            ruleAbstractElement();

            state._fsp--;

             after(grammarAccess.getModelAccess().getElementsAbstractElementParserRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__ElementsAssignment"


    // $ANTLR start "rule__Story__StoriesAssignment"
    // InternalDSL.g:1162:1: rule__Story__StoriesAssignment : ( rulePartOfStory ) ;
    public final void rule__Story__StoriesAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1166:1: ( ( rulePartOfStory ) )
            // InternalDSL.g:1167:2: ( rulePartOfStory )
            {
            // InternalDSL.g:1167:2: ( rulePartOfStory )
            // InternalDSL.g:1168:3: rulePartOfStory
            {
             before(grammarAccess.getStoryAccess().getStoriesPartOfStoryParserRuleCall_0()); 
            pushFollow(FOLLOW_2);
            rulePartOfStory();

            state._fsp--;

             after(grammarAccess.getStoryAccess().getStoriesPartOfStoryParserRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Story__StoriesAssignment"


    // $ANTLR start "rule__PartOfStory__NameAssignment_1"
    // InternalDSL.g:1177:1: rule__PartOfStory__NameAssignment_1 : ( ruleNameWithUnderscore ) ;
    public final void rule__PartOfStory__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1181:1: ( ( ruleNameWithUnderscore ) )
            // InternalDSL.g:1182:2: ( ruleNameWithUnderscore )
            {
            // InternalDSL.g:1182:2: ( ruleNameWithUnderscore )
            // InternalDSL.g:1183:3: ruleNameWithUnderscore
            {
             before(grammarAccess.getPartOfStoryAccess().getNameNameWithUnderscoreParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleNameWithUnderscore();

            state._fsp--;

             after(grammarAccess.getPartOfStoryAccess().getNameNameWithUnderscoreParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PartOfStory__NameAssignment_1"


    // $ANTLR start "rule__PartOfStory__StartAssignment_3"
    // InternalDSL.g:1192:1: rule__PartOfStory__StartAssignment_3 : ( RULE_START ) ;
    public final void rule__PartOfStory__StartAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1196:1: ( ( RULE_START ) )
            // InternalDSL.g:1197:2: ( RULE_START )
            {
            // InternalDSL.g:1197:2: ( RULE_START )
            // InternalDSL.g:1198:3: RULE_START
            {
             before(grammarAccess.getPartOfStoryAccess().getStartSTARTTerminalRuleCall_3_0()); 
            match(input,RULE_START,FOLLOW_2); 
             after(grammarAccess.getPartOfStoryAccess().getStartSTARTTerminalRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PartOfStory__StartAssignment_3"


    // $ANTLR start "rule__PartOfStory__GameTextsAssignment_4"
    // InternalDSL.g:1207:1: rule__PartOfStory__GameTextsAssignment_4 : ( ruleGameText ) ;
    public final void rule__PartOfStory__GameTextsAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1211:1: ( ( ruleGameText ) )
            // InternalDSL.g:1212:2: ( ruleGameText )
            {
            // InternalDSL.g:1212:2: ( ruleGameText )
            // InternalDSL.g:1213:3: ruleGameText
            {
             before(grammarAccess.getPartOfStoryAccess().getGameTextsGameTextParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleGameText();

            state._fsp--;

             after(grammarAccess.getPartOfStoryAccess().getGameTextsGameTextParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PartOfStory__GameTextsAssignment_4"


    // $ANTLR start "rule__PartOfStory__QuestionAssignment_5"
    // InternalDSL.g:1222:1: rule__PartOfStory__QuestionAssignment_5 : ( ruleQuestion ) ;
    public final void rule__PartOfStory__QuestionAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1226:1: ( ( ruleQuestion ) )
            // InternalDSL.g:1227:2: ( ruleQuestion )
            {
            // InternalDSL.g:1227:2: ( ruleQuestion )
            // InternalDSL.g:1228:3: ruleQuestion
            {
             before(grammarAccess.getPartOfStoryAccess().getQuestionQuestionParserRuleCall_5_0()); 
            pushFollow(FOLLOW_2);
            ruleQuestion();

            state._fsp--;

             after(grammarAccess.getPartOfStoryAccess().getQuestionQuestionParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PartOfStory__QuestionAssignment_5"


    // $ANTLR start "rule__PartOfStory__AllOptionsAssignment_6_0"
    // InternalDSL.g:1237:1: rule__PartOfStory__AllOptionsAssignment_6_0 : ( ruleOptions ) ;
    public final void rule__PartOfStory__AllOptionsAssignment_6_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1241:1: ( ( ruleOptions ) )
            // InternalDSL.g:1242:2: ( ruleOptions )
            {
            // InternalDSL.g:1242:2: ( ruleOptions )
            // InternalDSL.g:1243:3: ruleOptions
            {
             before(grammarAccess.getPartOfStoryAccess().getAllOptionsOptionsParserRuleCall_6_0_0()); 
            pushFollow(FOLLOW_2);
            ruleOptions();

            state._fsp--;

             after(grammarAccess.getPartOfStoryAccess().getAllOptionsOptionsParserRuleCall_6_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PartOfStory__AllOptionsAssignment_6_0"


    // $ANTLR start "rule__PartOfStory__GotoAssignment_6_1"
    // InternalDSL.g:1252:1: rule__PartOfStory__GotoAssignment_6_1 : ( ruleGoTo ) ;
    public final void rule__PartOfStory__GotoAssignment_6_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1256:1: ( ( ruleGoTo ) )
            // InternalDSL.g:1257:2: ( ruleGoTo )
            {
            // InternalDSL.g:1257:2: ( ruleGoTo )
            // InternalDSL.g:1258:3: ruleGoTo
            {
             before(grammarAccess.getPartOfStoryAccess().getGotoGoToParserRuleCall_6_1_0()); 
            pushFollow(FOLLOW_2);
            ruleGoTo();

            state._fsp--;

             after(grammarAccess.getPartOfStoryAccess().getGotoGoToParserRuleCall_6_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PartOfStory__GotoAssignment_6_1"


    // $ANTLR start "rule__GameText__ContentAssignment_1"
    // InternalDSL.g:1267:1: rule__GameText__ContentAssignment_1 : ( RULE_STRING ) ;
    public final void rule__GameText__ContentAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1271:1: ( ( RULE_STRING ) )
            // InternalDSL.g:1272:2: ( RULE_STRING )
            {
            // InternalDSL.g:1272:2: ( RULE_STRING )
            // InternalDSL.g:1273:3: RULE_STRING
            {
             before(grammarAccess.getGameTextAccess().getContentSTRINGTerminalRuleCall_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getGameTextAccess().getContentSTRINGTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameText__ContentAssignment_1"


    // $ANTLR start "rule__Question__ContentAssignment_1"
    // InternalDSL.g:1282:1: rule__Question__ContentAssignment_1 : ( RULE_STRING ) ;
    public final void rule__Question__ContentAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1286:1: ( ( RULE_STRING ) )
            // InternalDSL.g:1287:2: ( RULE_STRING )
            {
            // InternalDSL.g:1287:2: ( RULE_STRING )
            // InternalDSL.g:1288:3: RULE_STRING
            {
             before(grammarAccess.getQuestionAccess().getContentSTRINGTerminalRuleCall_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getQuestionAccess().getContentSTRINGTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Question__ContentAssignment_1"


    // $ANTLR start "rule__Options__OptionsAssignment_1"
    // InternalDSL.g:1297:1: rule__Options__OptionsAssignment_1 : ( ruleOption ) ;
    public final void rule__Options__OptionsAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1301:1: ( ( ruleOption ) )
            // InternalDSL.g:1302:2: ( ruleOption )
            {
            // InternalDSL.g:1302:2: ( ruleOption )
            // InternalDSL.g:1303:3: ruleOption
            {
             before(grammarAccess.getOptionsAccess().getOptionsOptionParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleOption();

            state._fsp--;

             after(grammarAccess.getOptionsAccess().getOptionsOptionParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Options__OptionsAssignment_1"


    // $ANTLR start "rule__Options__OptionsAssignment_2_1"
    // InternalDSL.g:1312:1: rule__Options__OptionsAssignment_2_1 : ( ruleOption ) ;
    public final void rule__Options__OptionsAssignment_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1316:1: ( ( ruleOption ) )
            // InternalDSL.g:1317:2: ( ruleOption )
            {
            // InternalDSL.g:1317:2: ( ruleOption )
            // InternalDSL.g:1318:3: ruleOption
            {
             before(grammarAccess.getOptionsAccess().getOptionsOptionParserRuleCall_2_1_0()); 
            pushFollow(FOLLOW_2);
            ruleOption();

            state._fsp--;

             after(grammarAccess.getOptionsAccess().getOptionsOptionParserRuleCall_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Options__OptionsAssignment_2_1"


    // $ANTLR start "rule__Option__NameAssignment_0"
    // InternalDSL.g:1327:1: rule__Option__NameAssignment_0 : ( RULE_OPT_ID ) ;
    public final void rule__Option__NameAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1331:1: ( ( RULE_OPT_ID ) )
            // InternalDSL.g:1332:2: ( RULE_OPT_ID )
            {
            // InternalDSL.g:1332:2: ( RULE_OPT_ID )
            // InternalDSL.g:1333:3: RULE_OPT_ID
            {
             before(grammarAccess.getOptionAccess().getNameOPT_IDTerminalRuleCall_0_0()); 
            match(input,RULE_OPT_ID,FOLLOW_2); 
             after(grammarAccess.getOptionAccess().getNameOPT_IDTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Option__NameAssignment_0"


    // $ANTLR start "rule__Option__ContentAssignment_2"
    // InternalDSL.g:1342:1: rule__Option__ContentAssignment_2 : ( RULE_STRING ) ;
    public final void rule__Option__ContentAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1346:1: ( ( RULE_STRING ) )
            // InternalDSL.g:1347:2: ( RULE_STRING )
            {
            // InternalDSL.g:1347:2: ( RULE_STRING )
            // InternalDSL.g:1348:3: RULE_STRING
            {
             before(grammarAccess.getOptionAccess().getContentSTRINGTerminalRuleCall_2_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getOptionAccess().getContentSTRINGTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Option__ContentAssignment_2"


    // $ANTLR start "rule__Option__GotoAssignment_3"
    // InternalDSL.g:1357:1: rule__Option__GotoAssignment_3 : ( ruleGoTo ) ;
    public final void rule__Option__GotoAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1361:1: ( ( ruleGoTo ) )
            // InternalDSL.g:1362:2: ( ruleGoTo )
            {
            // InternalDSL.g:1362:2: ( ruleGoTo )
            // InternalDSL.g:1363:3: ruleGoTo
            {
             before(grammarAccess.getOptionAccess().getGotoGoToParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleGoTo();

            state._fsp--;

             after(grammarAccess.getOptionAccess().getGotoGoToParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Option__GotoAssignment_3"


    // $ANTLR start "rule__GoTo__NextPartAssignment_1"
    // InternalDSL.g:1372:1: rule__GoTo__NextPartAssignment_1 : ( ( RULE_ID ) ) ;
    public final void rule__GoTo__NextPartAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDSL.g:1376:1: ( ( ( RULE_ID ) ) )
            // InternalDSL.g:1377:2: ( ( RULE_ID ) )
            {
            // InternalDSL.g:1377:2: ( ( RULE_ID ) )
            // InternalDSL.g:1378:3: ( RULE_ID )
            {
             before(grammarAccess.getGoToAccess().getNextPartPartOfStoryCrossReference_1_0()); 
            // InternalDSL.g:1379:3: ( RULE_ID )
            // InternalDSL.g:1380:4: RULE_ID
            {
             before(grammarAccess.getGoToAccess().getNextPartPartOfStoryIDTerminalRuleCall_1_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getGoToAccess().getNextPartPartOfStoryIDTerminalRuleCall_1_0_1()); 

            }

             after(grammarAccess.getGoToAccess().getNextPartPartOfStoryCrossReference_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoTo__NextPartAssignment_1"

    // Delegated rules


    protected DFA2 dfa2 = new DFA2(this);
    static final String dfa_1s = "\41\uffff";
    static final String dfa_2s = "\1\1\40\uffff";
    static final String dfa_3s = "\1\15\1\uffff\1\4\1\16\1\4\1\5\1\16\1\20\1\6\1\20\1\17\2\6\1\7\1\uffff\1\4\1\20\1\21\1\24\3\17\1\6\1\25\1\4\1\22\1\7\1\17\1\24\1\6\1\25\1\4\1\22";
    static final String dfa_4s = "\1\15\1\uffff\1\4\1\26\1\4\1\20\1\26\1\20\1\6\1\20\1\25\2\6\1\7\1\uffff\1\4\1\20\1\21\1\24\1\17\2\25\1\6\1\25\1\4\1\23\1\7\1\22\1\24\1\6\1\25\1\4\1\23";
    static final String dfa_5s = "\1\uffff\1\2\14\uffff\1\1\22\uffff";
    static final String dfa_6s = "\41\uffff}>";
    static final String[] dfa_7s = {
            "\1\2",
            "",
            "\1\3",
            "\1\5\7\uffff\1\4",
            "\1\6",
            "\1\7\12\uffff\1\10",
            "\1\5\7\uffff\1\4",
            "\1\10",
            "\1\11",
            "\1\12",
            "\1\16\1\13\1\14\1\15\2\uffff\1\17",
            "\1\20",
            "\1\21",
            "\1\22",
            "",
            "\1\23",
            "\1\24",
            "\1\25",
            "\1\26",
            "\1\16",
            "\1\16\1\13\1\14\1\15\2\uffff\1\17",
            "\1\16\2\uffff\1\15\2\uffff\1\17",
            "\1\27",
            "\1\30",
            "\1\31",
            "\1\33\1\32",
            "\1\34",
            "\1\16\2\uffff\1\15",
            "\1\35",
            "\1\36",
            "\1\37",
            "\1\40",
            "\1\33\1\32"
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final short[] dfa_2 = DFA.unpackEncodedString(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final char[] dfa_4 = DFA.unpackEncodedStringToUnsignedChars(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[] dfa_6 = DFA.unpackEncodedString(dfa_6s);
    static final short[][] dfa_7 = unpackEncodedStringArray(dfa_7s);

    class DFA2 extends DFA {

        public DFA2(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 2;
            this.eot = dfa_1;
            this.eof = dfa_2;
            this.min = dfa_3;
            this.max = dfa_4;
            this.accept = dfa_5;
            this.special = dfa_6;
            this.transition = dfa_7;
        }
        public String getDescription() {
            return "()* loopback of 125:4: ( rule__Story__StoriesAssignment )*";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000002002L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000040002L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000010020L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000260000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000010022L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x00000000000C0000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000080002L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000000400002L});

}